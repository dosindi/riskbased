/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package converter;

import com.vaadin.data.util.converter.Converter;
import java.util.Locale;
import org.vaadin.spring.samples.security.shared.backend.Users;

/**
 *
 * @author BRAVOH05
 */
public class UsersConverter implements Converter<String, Users> {

    @Override
    public Users convertToModel(String value, Class<? extends Users> targetType, Locale locale) throws ConversionException {
        return null;
    }

    @Override
    public String convertToPresentation(Users value, Class<? extends String> targetType, Locale locale) throws ConversionException {
        return value.getUsername();
    }

    @Override
    public Class<Users> getModelType() {
        return Users.class;
    }

    @Override
    public Class<String> getPresentationType() {
        return String.class;
    }

}
