package org.vaadin.spring.samples.security.shared.backend;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author Duncan N
 */
public interface RiskProductRepository  extends JpaRepository<RiskProduct, Long> {

}