package org.vaadin.spring.samples.security.shared.views;

import com.vaadin.ui.Component;
import com.vaadin.ui.DateField;
import com.vaadin.ui.TextField;
import com.vaadin.ui.themes.ValoTheme;
import javax.annotation.PostConstruct;
import org.vaadin.spring.samples.security.shared.backend.RiskProduct;
import org.vaadin.teemu.switchui.Switch;
import org.vaadin.viritin.fields.MTextField;
import org.vaadin.viritin.form.AbstractForm;
import org.vaadin.viritin.layouts.MFormLayout;
import org.vaadin.viritin.layouts.MVerticalLayout;

public class RiskProductEntryForm extends AbstractForm<RiskProduct> {

    
      private final TextField id = new MTextField("id").withFullWidth();
      private final TextField product_description = new MTextField("product_description").withFullWidth();
      private final TextField hscode = new MTextField("hscode").withFullWidth();
      private final TextField risk_level = new MTextField("risk_level").withFullWidth();
      private final TextField created_by = new MTextField("created_by").withFullWidth();
      private final TextField created_on = new MTextField("created_on").withFullWidth();

    //DateField birthDate = new DateField("Birth day");
    //TypedSelect<RoleStatus> role = new TypedSelect().withCaption("Role");
    //Switch colleague = new Switch("ADMIN");

    RiskProductEntryForm(RiskProduct entry) {
        setSizeUndefined();
        setEntity(entry);
    }

    @Override
    protected Component createContent() {
        return new MVerticalLayout(
                new MFormLayout(
                            id ,
                            product_description ,
                            hscode ,
                            risk_level ,
                            created_by ,
                            created_on 
                ).withFullWidth(),
                getToolbar()
        ).withStyleName(ValoTheme.LAYOUT_CARD);
    }

    @PostConstruct
    void init() {
        setEagerValidation(true);
    }

}