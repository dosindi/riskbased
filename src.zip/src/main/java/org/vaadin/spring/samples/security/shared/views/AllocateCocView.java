package org.vaadin.spring.samples.security.shared.views;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.server.FontAwesome;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.VerticalLayout;
import javax.annotation.PostConstruct;
import org.springframework.security.access.annotation.Secured;
import org.vaadin.spring.samples.security.shared.Sections;
import org.vaadin.spring.sidebar.annotation.FontAwesomeIcon;
import org.vaadin.spring.sidebar.annotation.SideBarItem;
import org.vaadin.viritin.label.Header;
import org.vaadin.viritin.layouts.MVerticalLayout;

/**
 *
 * @author BRAVOH05
 */
@Secured({"ROLE_ADMIN", "ROLE_DATA_ENTRY","ROLE_RISK_MANAGER" })
@SpringView(name = "AllocateCocView")
@SideBarItem(sectionId = Sections.VIEWS, caption = "Allocate COC")
@FontAwesomeIcon(FontAwesome.BOLT)
public class AllocateCocView extends CssLayout implements View {

    public static final String VIEW_NAME="AllocateCocView";
    
    public VerticalLayout parent = new MVerticalLayout();
    public Header header = new Header("Allocate COC").setHeaderLevel(2);

    @PostConstruct
    public void init() {

        setWidth("100%");
        setHeight("100%");
        
        parent.addComponent(header);
        addComponent(parent);
    }

    
    public void enter(ViewChangeListener.ViewChangeEvent event) {
    
    }

}
