package org.vaadin.spring.samples.security.shared.views;

import com.vaadin.data.Property;
import com.vaadin.ui.Component;
import com.vaadin.ui.OptionGroup;
import com.vaadin.ui.PasswordField;
import com.vaadin.ui.TextField;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.PostConstruct;
import org.vaadin.spring.samples.security.shared.Common;
import org.vaadin.spring.samples.security.shared.backend.User_roles;
import org.vaadin.spring.samples.security.shared.backend.Users;
import org.vaadin.teemu.switchui.Switch;
import org.vaadin.viritin.fields.MPasswordField;
import org.vaadin.viritin.fields.MTextField;
import org.vaadin.viritin.form.AbstractForm;
import org.vaadin.viritin.layouts.MFormLayout;
import org.vaadin.viritin.layouts.MVerticalLayout;

public class UsersEntryForm extends AbstractForm<Users> {

    TextField username = new MTextField("Username");
    TextField fullname = new MTextField("FullName");
    TextField email = new MTextField("Email");
    TextField phoneNumber = new MTextField("Phone");
    private final OptionGroup user_role = new OptionGroup("Role");
    private final Switch enabled = new Switch("Active?");
    public Map<Integer, String> selectedRole = new HashMap<>();
    private final PasswordField password = new MPasswordField("Password");

    private final Common common = new Common();

    UsersEntryForm(Users entry, User_roles selected_user_roles) {
        setSizeUndefined();
        setEntity(entry);
        if (selected_user_roles != null) {
            user_role.select(selected_user_roles.getRole());
        }
    }

    @Override
    protected Component createContent() {
        user_role.addItems(common.ROLE_ADMIN, common.ROLE_DATA_ENTRY, common.ROLE_SUPERVISOR, common.ROLE_INSPECTOR,common.ROLE_RISK_MANAGER);
        user_role.addValueChangeListener((Property.ValueChangeEvent event) -> {
            selectedRole.put(1, (String) event.getProperty().getValue());
        });
        return new MVerticalLayout(
                new MFormLayout(
                        fullname,
                        email,
                        phoneNumber,
                        username,
                        password,
                        user_role,
                        enabled
                ).withWidth(""),
                getToolbar()
        ).withWidth("");
    }

    @PostConstruct
    public void init() {
        setEagerValidation(true);
    }

}
