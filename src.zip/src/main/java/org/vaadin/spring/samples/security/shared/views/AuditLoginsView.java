package org.vaadin.spring.samples.security.shared.views;

import com.mysql.jdbc.StringUtils;
import com.vaadin.event.FieldEvents;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.server.FontAwesome;
import com.vaadin.shared.ui.MarginInfo;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.TextField;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.vaadin.spring.samples.security.shared.Sections;
import org.vaadin.spring.samples.security.shared.backend.AuditLogins;
import org.vaadin.spring.samples.security.shared.backend.AuditLoginsRepository;
import org.vaadin.spring.sidebar.annotation.FontAwesomeIcon;
import org.vaadin.spring.sidebar.annotation.SideBarItem;
import org.vaadin.viritin.button.ConfirmButton;
import org.vaadin.viritin.button.MButton;
import org.vaadin.viritin.fields.MTable;
import org.vaadin.viritin.fields.MTextField;
import org.vaadin.viritin.label.Header;
import org.vaadin.viritin.layouts.MHorizontalLayout;
import org.vaadin.viritin.layouts.MVerticalLayout;

/*
*   @Author Bravoh05
*   @Description AuditLoginsEntryView
*
*
 */
@Secured({"ROLE_SUPER"})
@SpringView(name = "AuditLogins")
@SideBarItem(sectionId = Sections.VIEWS, caption = "AuditLogins")
@FontAwesomeIcon(FontAwesome.MAGIC)
public class AuditLoginsView extends MVerticalLayout implements View {

    @Autowired
    AuditLoginsRepository repo;

    private final MTable<AuditLogins> list = new MTable<>(AuditLogins.class)
            .withProperties("logId", "username", "loginStatus", "createdOn")
            .withColumnHeaders("#", "Name", "Status", "CreatedOn")
            .setSortableProperties("username", "loginStatus", "createdOn")
            .withHeight("300px").withFullWidth();

    private final TextField filter = new MTextField();
    private final Button addNew = new MButton(FontAwesome.PLUS, this::add);
    private final Button edit = new MButton(FontAwesome.PENCIL_SQUARE_O, this::edit);
    private final Button delete = new ConfirmButton(FontAwesome.TRASH_O,
            "Are you sure you want to delete the entry?", this::remove);
    private final Header header = new Header("AuditLogins").setHeaderLevel(2);

    @Override
    public void enter(ViewChangeListener.ViewChangeEvent viewChangeEvent) {
        listEntities();
    }

    @PostConstruct
    void init() {

        filter.setInputPrompt("Search");
        filter.addTextChangeListener((FieldEvents.TextChangeEvent event) -> {
            listFilterEntities(event.getText());
        });
        add(
                new MVerticalLayout(
                        new MHorizontalLayout(header, addNew, edit, delete, filter)
                        .space().expand(header)
                        .alignAll(Alignment.MIDDLE_LEFT)
                )
        );
        expand(list);
        setMargin(new MarginInfo(false, true, true, true));
        list.addMValueChangeListener(e -> adjustActionButtonState());
    }

    protected void adjustActionButtonState() {
        boolean hasSelection = list.getValue() != null;
        edit.setEnabled(hasSelection);
        delete.setEnabled(hasSelection);
    }

    static final int PAGESIZE = 45;

    private void listEntities() {
        list.setBeans(repo.findAll());
        adjustActionButtonState();
    }

    public void add(Button.ClickEvent clickEvent) {
        edit(new AuditLogins());
    }

    public void edit(Button.ClickEvent e) {
        edit(list.getValue());
    }

    public void remove(Button.ClickEvent e) {
        repo.delete(list.getValue());
        list.setValue(null);
        listEntities();
    }

    /*
     * @param filter search
     * 
     */
    public void listFilterEntities(String filterText) {

        if (StringUtils.isNullOrEmpty(filterText)) {
            list.setBeans(repo.findAll());
        } else {
            list.setBeans(repo.findByUsernameStartsWithIgnoreCase(filterText));
        }
        adjustActionButtonState();
    }

    protected void edit(final AuditLogins entry) {
//        AuditLoginsEntryForm entryForm = new AuditLoginsEntryForm(
//                entry);
//        entryForm.openInModalPopup();
//        entryForm.setSavedHandler(this::saveEntry);
//        entryForm.setResetHandler(this::resetEntry);
    }

    public void saveEntry(AuditLogins entry) {
        repo.save(entry);
        listEntities();
        closeWindow();
    }

    public void resetEntry(AuditLogins entry) {
        listEntities();
        closeWindow();
    }

    protected void closeWindow() {
        getUI().getWindows().stream().forEach(w -> getUI().removeWindow(w));
    }
}
