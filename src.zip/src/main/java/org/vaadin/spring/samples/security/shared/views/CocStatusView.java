/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.vaadin.spring.samples.security.shared.views;

import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.server.FontAwesome;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.VerticalLayout;
import javax.annotation.PostConstruct;
import org.springframework.security.access.annotation.Secured;
import org.vaadin.spring.samples.security.shared.Sections;
import org.vaadin.spring.sidebar.annotation.FontAwesomeIcon;
import org.vaadin.spring.sidebar.annotation.SideBarItem;
import org.vaadin.viritin.label.Header;
import org.vaadin.viritin.layouts.MVerticalLayout;

/**
 *
 * @author BRAVOH05
 */
//@Secured({"ROLE_SUPERVISOR", "ROLE_ADMIN", "ROLE_DATA_ENTRY"})
//@SpringView(name = "CocStatusView")
//@SideBarItem(sectionId = Sections.VIEWS, caption = "COC Status")
//@FontAwesomeIcon(FontAwesome.BOLT)
public class CocStatusView extends CssLayout implements View {

    public static final String VIEW_NAME="CocStatusView";
    
    public VerticalLayout parent = new MVerticalLayout();
    public Header header = new Header("COC Status").setHeaderLevel(2);

    @PostConstruct
    public void init() {

        setWidth("100%");
        setHeight("100%");
        
        parent.addComponents(header);
        addComponent(parent);
    }

    
    public void enter(ViewChangeListener.ViewChangeEvent event) {
    
    }

}
