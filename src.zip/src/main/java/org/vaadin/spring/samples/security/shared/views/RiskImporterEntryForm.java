package org.vaadin.spring.samples.security.shared.views;

import com.vaadin.ui.Component;
import com.vaadin.ui.DateField;
import com.vaadin.ui.TextField;
import com.vaadin.ui.themes.ValoTheme;
import javax.annotation.PostConstruct;
import org.vaadin.spring.samples.security.shared.backend.RiskImporter;
import org.vaadin.viritin.fields.MTextField;
import org.vaadin.viritin.form.AbstractForm;
import org.vaadin.viritin.layouts.MFormLayout;
import org.vaadin.viritin.layouts.MVerticalLayout;

public class RiskImporterEntryForm extends AbstractForm<RiskImporter> {

    
      private final TextField id = new MTextField("id").withFullWidth();
      private final TextField importer_name = new MTextField("Importer Name").withFullWidth();
      private final TextField importer_pin = new MTextField("Importer Pin").withFullWidth();
      private final TextField address = new MTextField("Address").withFullWidth();
      private final TextField risk_level = new MTextField("Risk Level").withFullWidth();
      private final TextField country = new MTextField("Country").withFullWidth();

    //DateField birthDate = new DateField("Birth day");
    //TypedSelect<RoleStatus> role = new TypedSelect().withCaption("Role");
    //Switch colleague = new Switch("ADMIN");

    RiskImporterEntryForm(RiskImporter entry) {
        setSizeUndefined();
        setEntity(entry);
    }

    @Override
    protected Component createContent() {
        return new MVerticalLayout(
                new MFormLayout(
                            id ,
                            importer_name ,
                            importer_pin ,
                            address ,
                            risk_level ,
                            country 
                ).withFullWidth(),
                getToolbar()
        ).withStyleName(ValoTheme.LAYOUT_CARD);
    }

    @PostConstruct
    void init() {
        setEagerValidation(true);
    }

}