/*
 * Copyright 2015 The original authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.vaadin.spring.samples.security.shared;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.AuthenticationException;
import org.vaadin.spring.security.shared.VaadinSharedSecurity;

import com.vaadin.annotations.Theme;
import com.vaadin.event.ShortcutAction;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Page;
import com.vaadin.server.ThemeResource;
import com.vaadin.server.VaadinRequest;
import com.vaadin.spring.annotation.SpringUI;
import com.vaadin.ui.*;
import com.vaadin.ui.themes.ValoTheme;
import org.springframework.security.core.Authentication;
import org.vaadin.spring.samples.security.shared.backend.AuditLogins;
import org.vaadin.spring.samples.security.shared.backend.AuditLoginsRepository;
import org.vaadin.viritin.label.Header;
import java.util.Date;
/**
 * UI for the login screen.
 *
 * @author Petter Holmström (petter@vaadin.com)
 */
@SpringUI(path = "/login")
@Theme(ValoTheme.THEME_NAME)
public class LoginUI extends UI {

    @Autowired
    VaadinSharedSecurity vaadinSecurity;

    @Autowired
    AuditLoginsRepository logRepo;

    private TextField userName;

    private PasswordField passwordField;

    private CheckBox rememberMe;

    private Button login;

    private Label loginFailedLabel;
    private Label loggedOutLabel;

    private Common common = new Common();
    
    @Override
    protected void init(VaadinRequest request) {
        getPage().setTitle(common.appname);

        FormLayout loginForm = new FormLayout();
        Image logo = new Image("",new ThemeResource("logo.png"));
        Header header = new Header("Welcome to "+common.appname).setHeaderLevel(2);
        loginForm.setStyleName(ValoTheme.LAYOUT_CARD);
        loginForm.setSizeUndefined();
        
        userName = new TextField("Username");
        passwordField = new PasswordField("Password");
        rememberMe = new CheckBox("Remember me");
        
        userName.setValue("admin");
        passwordField.setValue("password");
        
        login = new Button("Login");
        loginForm.addComponent(userName);
        loginForm.addComponent(passwordField);
        loginForm.addComponent(rememberMe);
        loginForm.addComponent(login);
        login.addStyleName(ValoTheme.BUTTON_PRIMARY);
        login.setIcon(FontAwesome.SIGN_IN);
        login.setDisableOnClick(true);
        login.setClickShortcut(ShortcutAction.KeyCode.ENTER);
        login.addClickListener((Button.ClickEvent event) -> {
            login();
        });

        VerticalLayout loginLayout = new VerticalLayout();
        loginLayout.setSpacing(true);
        loginLayout.setSizeUndefined();

        if (request.getParameter("logout") != null) {
            loggedOutLabel = new Label("You have been logged out!");
            loggedOutLabel.addStyleName(ValoTheme.LABEL_SUCCESS);
            loggedOutLabel.setSizeUndefined();
            loginLayout.addComponent(loggedOutLabel);
            loginLayout.setComponentAlignment(loggedOutLabel, Alignment.BOTTOM_CENTER);
        }

        loginLayout.addComponent(loginFailedLabel = new Label());
        loginLayout.setComponentAlignment(loginFailedLabel, Alignment.BOTTOM_CENTER);
        loginFailedLabel.setSizeUndefined();
        loginFailedLabel.addStyleName(ValoTheme.LABEL_FAILURE);
        loginFailedLabel.setVisible(false);

        loginLayout.addComponents(logo,header, loginForm);
        loginLayout.setComponentAlignment(logo, Alignment.TOP_CENTER);
        loginLayout.setComponentAlignment(loginForm, Alignment.TOP_CENTER);

        VerticalLayout rootLayout = new VerticalLayout(loginLayout);
        rootLayout.setSizeFull();
        rootLayout.setComponentAlignment(loginLayout, Alignment.MIDDLE_CENTER);
//        setStyle();

        setContent(rootLayout);
        setSizeFull();
    }

    private void login() {
        AuditLogins s = new AuditLogins();
        s.setUsername(userName.getValue());

        try {
            Authentication token = vaadinSecurity.login(userName.getValue(), passwordField.getValue(), rememberMe.getValue());
			s.setCreatedOn(new Date());
            s.setLoginStatus(AuditLogins.LoginStatus.SUCCESSFUL);
            logRepo.save(s);
            UI.getCurrent().getSession().setAttribute("token", token);
        } catch (AuthenticationException ex) {
         
            userName.focus();
            userName.selectAll();
            passwordField.setValue("");
            loginFailedLabel.setValue(String.format("Login failed: %s", ex.getMessage()));
            loginFailedLabel.setVisible(true);
            if (loggedOutLabel != null) {
                loggedOutLabel.setVisible(false);
            }

            s.setLoginStatus(AuditLogins.LoginStatus.FAILED);
			s.setCreatedOn(new Date());
            logRepo.save(s);
        } catch (Exception ex) {
            Notification.show("An unexpected error occurred", ex.getMessage(), Notification.Type.ERROR_MESSAGE);
            LoggerFactory.getLogger(getClass()).error("Unexpected error while logging in", ex);

            s.setLoginStatus(AuditLogins.LoginStatus.ERROR);
            logRepo.save(s);
        } finally {
            login.setEnabled(true);
        }
    }
    
        private void setStyle() {

        setStyleName("login");
        Page.Styles p = Page.getCurrent().getStyles();
		p.add(" @keyframes animatedBackground { "+
						"from { background-position: 0 0; }"+
						"to { background-position: -400px 0; }"+
					"}");
		p.add(".login .v-formlayout{ "+
			"width: 100%; "+
			"height: 100%; "+
			"background: gray  "+
			"margin: 0  "+			
			"box-sizing: border-box; "+
			"background-image: url(./VAADIN/themes/valo/dark-honey-hive.png); "+
			"background-position: 0px 0px; "+
			"background-repeat: repeat-x; "+
			"animation: animatedBackground 40s linear infinite; "+
		"}");
    }
}
