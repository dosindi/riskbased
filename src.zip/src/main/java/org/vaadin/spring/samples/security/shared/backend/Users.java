/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.vaadin.spring.samples.security.shared.backend;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author BRAVOH05
 */
@Entity
@Table(name = "tb_users")
@NamedQueries({
    @NamedQuery(name = "Users.findCreator", query = "SELECT u FROM Users u WHERE LOWER(u.username) LIKE LOWER(CONCAT('%',:filter,'%'))")    
})
public class Users implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Getter
    @Setter
    private Long userid;
    @NotNull
    @Column(length = 45, unique = true)
    @Getter
    @Setter
    private String username;
    @Getter
    @Setter
    private String password;
    
    @Column(length = 150)
    @Getter
    @Setter
    private String fullname;
    
    @NotNull(message = "Email is required")
    @Pattern(regexp = ".+@.+\\.[a-z]+", message = "Must be valid email")
    @Getter
    @Setter
    private String email;
    
    @Getter
    @Setter
    private Boolean enabled;
    
    @Column(length=15)
    @Getter
    @Setter
    private String phoneNumber;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    @Getter
    @Setter
    private Date createdOn;
    
    @Override
    public String toString(){
        return getFullname();
    }

}
