package org.vaadin.spring.samples.security.shared.views;

import com.mysql.jdbc.StringUtils;
import com.vaadin.event.FieldEvents;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.server.FontAwesome;
import com.vaadin.shared.ui.MarginInfo;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.DateField;
import com.vaadin.ui.Label;
import com.vaadin.ui.TextField;
import java.util.Date;
import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.vaadin.spring.samples.security.shared.Common;
import org.vaadin.spring.samples.security.shared.Sections;
import org.vaadin.spring.samples.security.shared.backend.User_roles;
import org.vaadin.spring.samples.security.shared.backend.User_rolesRepository;
import org.vaadin.spring.samples.security.shared.backend.Users;
import org.vaadin.spring.samples.security.shared.backend.UsersRepository;
import org.vaadin.spring.sidebar.annotation.FontAwesomeIcon;
import org.vaadin.spring.sidebar.annotation.SideBarItem;
import org.vaadin.viritin.button.ConfirmButton;
import org.vaadin.viritin.button.MButton;
import org.vaadin.viritin.fields.MTable;
import org.vaadin.viritin.fields.MTextField;
import org.vaadin.viritin.label.Header;
import org.vaadin.viritin.layouts.MHorizontalLayout;
import org.vaadin.viritin.layouts.MVerticalLayout;

/**
 * View that is available for all users.
 *
 * @author Petter Holmström (petter@vaadin.com)
 */
@Secured({"ROLE_SUPER", "ROLE_ADMIN"})
@SpringView(name = "user")
@SideBarItem(sectionId = Sections.VIEWS, caption = "Users")
@FontAwesomeIcon(FontAwesome.USERS)
public class UserView extends MVerticalLayout implements View {

    @Autowired
    private UsersRepository repo;

    @Autowired
    private User_rolesRepository userRoleRepo;

    private final Common common = new Common();

    private MTable<Users> list = new MTable<>(Users.class)
            .withProperties("userid", "fullname", "email", "enabled")
            .withColumnHeaders("#", "FullName", "Email", "Active")
            .setSortableProperties("fullname", "email", "enabled")
            .withHeight("300px").withFullWidth();

    private final TextField filter = new MTextField();
    private final Button addNew = new MButton(FontAwesome.PLUS, this::add);
    private final Button edit = new MButton(FontAwesome.PENCIL_SQUARE_O, this::edit);
    private final Button delete = new ConfirmButton(FontAwesome.TRASH_O,
            "Are you sure you want to delete the entry?", this::remove);
    private final Button search = new MButton(FontAwesome.SEARCH, this::search);
    private final Header header = new Header("Users").setHeaderLevel(2);
    private final Label lblfrom = new Label("From:");
    private final Label lblto = new Label("To:");
    private final DateField from = new DateField();
    private final DateField to = new DateField();

    private User_roles selected_user_roles;

    private UsersEntryForm entryForm;

    @Override
    public void enter(ViewChangeListener.ViewChangeEvent viewChangeEvent) {
        listEntities();
    }

    @PostConstruct
    void init() {

        Date last30days1 = common.last30days;
        Date today1 = common.today;

        from.setDateFormat("yyyy-MM-dd");
        from.setValue(last30days1);

        to.setDateFormat("yyyy-MM-dd");
        to.setValue(today1);
        filter.setInputPrompt("Search");
        filter.addTextChangeListener((FieldEvents.TextChangeEvent event) -> {
            listFilterEntities(event.getText());
        });
        MHorizontalLayout dateFilter = new MHorizontalLayout();
        dateFilter.addComponents(lblfrom, from, lblto, to);//delete,
        add(
                new MVerticalLayout(header,
                        new MHorizontalLayout(filter, addNew, edit, dateFilter, search)
                        .expand(filter)
                        .alignAll(Alignment.MIDDLE_CENTER)
                )
        );
        expand(list);
        setMargin(new MarginInfo(false, true, true, true));
        list.addMValueChangeListener(e -> adjustActionButtonState());
    }

    protected void adjustActionButtonState() {
        boolean hasSelection = list.getValue() != null;
        edit.setEnabled(hasSelection);
        delete.setEnabled(hasSelection);
    }

    static final int PAGESIZE = 45;

    private void listEntities() {

        list.setBeans(repo.findAll());

        adjustActionButtonState();
    }

    public void add(Button.ClickEvent clickEvent) {
        edit(new Users());
    }

    public void edit(Button.ClickEvent e) {
        edit(list.getValue());
    }

    public void remove(Button.ClickEvent e) {
        Users users = list.getValue();
        users.setEnabled(Boolean.FALSE);
        repo.save(users);
        list.setValue(null);
        listEntities();
    }

    public void search(Button.ClickEvent e) {

    }

    public void listFilterEntities(String filterText) {

        if (StringUtils.isNullOrEmpty(filterText)) {
            list.setBeans(repo.findAll());
        } else {
            list.setBeans(repo.findByFullnameStartsWithIgnoreCase(filterText));
        }

    }

    protected void edit(final Users phoneBookEntry) {
        //Retrieve role
        selected_user_roles = null;
        if (phoneBookEntry != null) {
            selected_user_roles = userRoleRepo.findRole(phoneBookEntry.getUserid());
        } else {
            selected_user_roles = new User_roles();
        }
        entryForm = new UsersEntryForm(
                phoneBookEntry, selected_user_roles);
        entryForm.openInModalPopup();
        entryForm.setSavedHandler(this::saveEntry);
        entryForm.setResetHandler(this::resetEntry);

    }

    public void saveEntry(Users entry) {
        BCryptPasswordEncoder b = new BCryptPasswordEncoder();
        String enc = b.encode(entry.getPassword());
        entry.setPassword(enc);
        repo.saveAndFlush(entry);
        String selectedRole = entryForm.selectedRole.get(1);
        try {
            selected_user_roles.setRole(selectedRole);
            selected_user_roles.setUserid(entry.getUserid());
            userRoleRepo.save(selected_user_roles);
        } catch (NullPointerException e) {
            selected_user_roles = new User_roles();
            selected_user_roles.setRole(selectedRole);
            selected_user_roles.setUserid(entry.getUserid());
            userRoleRepo.save(selected_user_roles);
        }
        listEntities();
        closeWindow();
    }

    public void resetEntry(Users entry) {
        listEntities();
        closeWindow();
    }

    protected void closeWindow() {
        getUI().getWindows().stream().forEach(w -> getUI().removeWindow(w));
    }
}
