package org.vaadin.spring.samples.security.shared;

/**
 *
 * @author BRAVOH05
 * @Wants to connect
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import org.springframework.beans.factory.annotation.Value;


public class ConnectionHelper {

    @Value("${spring.datasource.url}")
    private String url;
    @Value("${spring.datasource.username}")
    private String userString;
    @Value("${spring.datasource.password}")
    private String passString;

    private String url1;

    private static ConnectionHelper instance;
    Common common = new Common();
    private ConnectionHelper() {

        try {
            Class.forName(common.driver);
            url1 = common.url;//"jdbc:mysql://"+common.ip+":"+common.port+"/ssmo?user="+common.username+"&password="+common.pass;

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Connection getConnection() throws SQLException {
        if (instance == null) {
            instance = new ConnectionHelper();
        }
        try {
            return DriverManager.getConnection(instance.url1);
        } catch (SQLException e) {
            throw e;
        }
    }

    public static void close(Connection connection) {
        try {
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
