/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.vaadin.spring.samples.security.shared.backend;

import org.springframework.security.access.prepost.PreAuthorize;

/**
 * Example backend interface with
 * {@link org.springframework.security.access.prepost.PreAuthorize} annotations.
 *
 * @author Petter Holmström (petter@vaadin.com)
 */
public interface MyBackend {

    @PreAuthorize("hasRole('ROLE_ACCOUNT')")
    String accountEcho(String s);

    @PreAuthorize("hasRole('ROLE_ADMIN')")
    String adminOnlyEcho(String s);

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_USER')")
    String echo(String s);

    @PreAuthorize("hasRole('ROLE_DESIGNER')")
    String designEcho(String s);

}
