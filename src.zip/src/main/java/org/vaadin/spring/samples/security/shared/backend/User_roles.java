/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.vaadin.spring.samples.security.shared.backend;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 *
 * @author BRAVOH05
 */
@Entity
@Table(name="tb_user_roles")
@NamedQueries({@NamedQuery(name = "User_roles.findRole",query = "SELECT r FROM User_roles r WHERE r.userid=:roleId")})
public class User_roles {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int user_role_id;

    @Column(name="userid")
    private Long userid;
    
    @NotNull
    private String role;

    /**
     * @return the user_role_id
     */
    public int getUser_role_id() {
        return user_role_id;
    }

    /**
     * @param user_role_id the user_role_id to set
     */
    public void setUser_role_id(int user_role_id) {
        this.user_role_id = user_role_id;
    }


    /**
     * @return the role
     */
    public String getRole() {
        return role;
    }

    /**
     * @param role the role to set
     */
    public void setRole(String role) {
        this.role = role;
    }

    
    /**
     * @return the userid
     */
    public Long getUserid() {
        return userid;
    }

    /**
     * @param userid the userid to set
     */
    public void setUserid(Long userid) {
        this.userid = userid;
    }
    
    
}
