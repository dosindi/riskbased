/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.vaadin.spring.samples.security.shared.backend;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author BRAVOH05
 */
@Entity
public class AuditLogins implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long logId;
    private String username;

    @Column(columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    @Temporal(value = TemporalType.TIMESTAMP)
    private Date createdOn;

    private LoginStatus loginStatus;

    /**
     * @param createdOn the createdOn to set
     */
    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    /**
     * @return the loginStatus
     */
    public LoginStatus getLoginStatus() {
        return loginStatus;
    }

    /**
     * @param loginStatus the loginStatus to set
     */
    public void setLoginStatus(LoginStatus loginStatus) {
        this.loginStatus = loginStatus;
    }

    public enum LoginStatus {
        SUCCESSFUL, FAILED, ERROR
    }
    
    

    /**
     * @return the logId
     */
    public Long getLogId() {
        return logId;
    }

    /**
     * @param logId the logId to set
     */
    public void setLogId(Long logId) {
        this.logId = logId;
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the createOn
     */
    public Date getCreatedOn() {
        return createdOn;
    }

    /**
     * @param createOn the createOn to set
     */
    public void setCreateOn(Date createdOn) {
        this.setCreatedOn(createdOn);
    }

}
