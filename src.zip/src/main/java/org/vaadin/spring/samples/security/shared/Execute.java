/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.vaadin.spring.samples.security.shared;

import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

/**
 *
 * @author BRAVOH05
 */
@Slf4j
@Component
public class Execute {
    
    @Async
    public void callProcess(){
    
     log.info("======starting Async ====>");
     StopWatch stopWatch = new StopWatch();
     stopWatch.start();
     log.info("===|STARTED|===");
     stopWatch.stop();
     log.info("===|Process Duration|==="+stopWatch.getTotalTimeMillis());
    }
}
