/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.vaadin.spring.samples.security.shared.backend;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author BRAVOH05
 */
@Entity
@Table(name = "tb_cocs")
@NamedQueries({
    @NamedQuery(name = "Cocs.findStatusAssignedTo", query = "SELECT c FROM Cocs c WHERE c.STATUS=:status AND c.ASSIGNED_INSPECTOR=:users"),
    @NamedQuery(name = "Cocs.findStatusSubStatusFromTo", query = "SELECT c FROM Cocs c WHERE c.DATE_ADDED BETWEEN :from AND :to AND c.STATUS=:status AND c.SUBSTATUS=:substatus"),
    @NamedQuery(name = "Cocs.findSubStatusFromTo", query = "SELECT c FROM Cocs c WHERE c.DATE_ADDED BETWEEN :from AND :to AND c.SUBSTATUS=:substatus"),
    @NamedQuery(name = "Cocs.findSubStatus", query = "SELECT c FROM Cocs c WHERE c.SUBSTATUS=:substatus"),
    @NamedQuery(name = "Cocs.findStatusFromTo", query = "SELECT c FROM Cocs c WHERE c.DATE_ADDED BETWEEN :from AND :to AND c.STATUS=:status"),
    @NamedQuery(name = "Cocs.findExporter", query = "SELECT c FROM Cocs c WHERE c.EXPORTER_NAME LIKE '%:exporter%'"),
    @NamedQuery(name = "Cocs.findImporter", query = "SELECT c FROM Cocs c WHERE c.IMPORTER_NAME LIKE '%:importer%'"),
    @NamedQuery(name = "Cocs.findIDF", query = "SELECT c FROM Cocs c WHERE c.IDF LIKE '%:filter%'"),
    @NamedQuery(name = "Cocs.findCOCNO", query = "SELECT c FROM Cocs c WHERE c.COCNO=:cocno"),
    @NamedQuery(name = "Cocs.findStatus", query = "SELECT c FROM Cocs c WHERE c.STATUS=:status"),
    @NamedQuery(name = "Cocs.findFromTo", query = "SELECT c FROM Cocs c WHERE c.DATE_ADDED BETWEEN :from AND :to")})
public class Cocs implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Getter
    @Setter
    @Column(length = 50)
    private long COCNO;

    @Getter
    @Setter
    @Column(length = 50)
    private String IDF;

    @Getter
    @Setter
    @Column(length = 100)
    private String IMPORTER_NAME;
    @Getter
    @Setter
    @Column(length = 100)
    private String EXPORTER_NAME;
    @Getter
    @Setter
    @Temporal(TemporalType.TIMESTAMP)
    private Date INSPECTION_DATE;
    @Setter
    @Getter
    @Column(length = 50)
    private String PLACE_OF_INSPECTION;
    @Setter
    @Getter
    @Column(length = 100)
    private String DESTINATION_PORT;

    @Setter
    @Getter
    @Column(length = 255)
    private String OVERALL_REMARKS;

    @Setter
    @Getter
    @Column(length = 100)
    private String SHIPMENT_MODE;
    @Setter
    @Getter
    @Column(length = 50)
    private String COUNTRY_OF_SUPPLY;
    @Setter
    @Getter
    @Column(length = 11)
    private int FOB_VALUE;
    @Setter
    @Getter
    @Column(length = 100)
    private String FOB_CURRENCY;

    @Setter
    @Getter
    @Column(length = 50)
    private String INVOICE_NO;
    @Setter
    @Getter
    @Temporal(TemporalType.TIMESTAMP)
    private Date INVOICE_DATE;

    @Setter
    @Getter
    @Column(length = 100)
    private String HS_CODE;

    @Setter
    @Getter
    @Column(length = 100)
    private String QUANTITY;

    @Setter
    @Getter
    @Column(length = 200)
    private String PRODUCT_DESCRIPTION;

    @Setter
    @Getter
    @Column(length = 100)
    private String STANDARD;
    @Setter
    @Getter
    @Column(length = 1000)
    private String FINDINGS_QUALITY;
    @Setter
    @Getter
    @Column(length = 100)
    private String FINDINGS_TESTING;

    @Setter
    @Getter
    @Enumerated(EnumType.STRING)
    private EntryStatus STATUS;

    @Setter
    @Getter
    @Enumerated(EnumType.STRING)
    private EntrySubStatus SUBSTATUS;

    @Setter
    @Getter
    private PackingStatus PACKING_DETAILS;

    @Setter
    @Getter
    @ManyToOne(optional = true)
    private Users ASSIGNED_INSPECTOR;

    @Setter
    @Getter
    @ManyToOne(optional = true)
    private Users ADDED_BY;
    @Setter
    @Getter
    @ManyToOne
    private Users EDITED_BY;
    @Setter
    @Getter
    @Temporal(TemporalType.TIMESTAMP)
    private Date DATE_ADDED;
    @Setter
    @Getter
    @Temporal(TemporalType.TIMESTAMP)
    private Date DATE_EDITED;

    /*
        issuance date
     */
    @Setter
    @Getter
    @Temporal(TemporalType.TIMESTAMP)
    private Date DATE_APPROVED;

    @Setter
    @Getter
    @ManyToOne
    private Users APPROVED_BY;

    @Setter
    @Getter
    @Column(length = 100)
    private String SUPERVISOR_REMARKS;

    @Getter
    @Setter
    @Column(length = 200)
    private String UPLOAD_TEST_RESULTS;

    @Getter
    @Setter
    @Column(length = 200)
    private String UPLOAD_INSPECTION_REPORT;

    /*
        Add importer_pin
            hscode
            exporter_pin
     */
    
    @Getter
    @Setter
    @Column(length = 5,columnDefinition = " DEFAULT 0")
    private int importer_pin;

    @Getter
    @Setter
    @Column(length = 5,columnDefinition = " DEFAULT 0")
    private int exporter_pin;

    @Getter
    @Setter
    @Column(length = 5,columnDefinition = " DEFAULT 0")
    private int hscode;

}
