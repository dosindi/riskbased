package org.vaadin.spring.samples.security.shared.views;

import com.vaadin.ui.ComboBox;
import com.vaadin.ui.Component;
import com.vaadin.ui.DateField;
import com.vaadin.ui.Label;
import com.vaadin.ui.TextArea;
import com.vaadin.ui.TextField;
import com.vaadin.ui.themes.ValoTheme;
import javax.annotation.PostConstruct;
import org.vaadin.spring.samples.security.shared.backend.Cocs;
import org.vaadin.spring.samples.security.shared.backend.EntryStatus;
import org.vaadin.spring.samples.security.shared.backend.User_roles;
import org.vaadin.viritin.fields.MTextField;
import org.vaadin.viritin.form.AbstractForm;
import org.vaadin.viritin.label.MLabel;
import org.vaadin.viritin.layouts.MFormLayout;
import org.vaadin.viritin.layouts.MHorizontalLayout;
import org.vaadin.viritin.layouts.MVerticalLayout;

public class CocsEntryForm extends AbstractForm<Cocs> {

    public final TextField COCNO = new MTextField("COCNO").withFullWidth();
    public final DateField ISSUANCE_DATE = new DateField("ISSUANCE_DATE");
    public final DateField RFC_DATE = new DateField("RFC_DATE");
    public final TextField IDF = new MTextField("IDF").withFullWidth();
    public final TextField IMPORTER_NAME = new MTextField("IMPORTER_NAME").withFullWidth();
    public final TextField EXPORTER_NAME = new MTextField("EXPORTER_NAME").withFullWidth();
    public final DateField INSPECTION_DATE = new DateField("INSPECTION_DATE");
    public final TextField PLACE_OF_INSPECTION = new MTextField("PLACE_OF_INSPECTION").withFullWidth();
    public final TextField DESTINATION_PORT = new MTextField("DESTINATION_PORT").withFullWidth();
    public final TextField SHIPMENT_MODE = new MTextField("SHIPMENT_MODE").withFullWidth();
    public final TextField COUNTRY_OF_SUPPLY = new MTextField("COUNTRY_OF_SUPPLY").withFullWidth();
    public final TextField FOB_VALUE = new MTextField("FOB_VALUE").withFullWidth();
    public final TextField FOB_CURRENCY = new MTextField("FOB_CURRENCY").withFullWidth();
    public final TextField INVOICE_NO = new MTextField("INVOICE_NO").withFullWidth();
    public final DateField INVOICE_DATE = new DateField("INVOICE_DATE");
    public final TextField HS_CODE = new MTextField("HS_CODE").withFullWidth();
    public final TextField QUANTITY = new MTextField("QUANTITY").withFullWidth();
    public final TextField PRODUCT_DESCRIPTION = new MTextField("PRODUCT_DESCRIPTION").withFullWidth();
    public final TextField STANDARD = new MTextField("STANDARD").withFullWidth();
    public final TextArea FINDINGS_QUALITY = new TextArea("FINDINGS_QUALITY");
    public final TextArea FINDINGS_TESTING = new TextArea("FINDINGS_TESTING");
    public final ComboBox STATUS = new ComboBox("STATUS");
    public final TextField ADDED_BY = new MTextField("ADDED_BY").withFullWidth();
    public final TextField EDITED_BY = new MTextField("EDITED_BY").withFullWidth();
    public final MLabel DATE_ADDED = new MLabel("DATE_ADDED").withFullWidth();
    public final TextField DATE_EDITED = new MTextField("DATE_EDITED").withFullWidth();
    public final Label DATE_APPROVED = new MLabel("DATE_APPROVED").withFullWidth();
    public final TextField APPROVED_BY = new MTextField("APPROVED_BY").withFullWidth();
    public final TextField SERIAL_NUMBER = new MTextField("SERIAL_NUMBER").withFullWidth();

    CocsEntryForm(Cocs entry, User_roles role) {
        setSizeUndefined();
        setEntity(entry);

    }

    @Override
    protected Component createContent() {

        STATUS.addItems(EntryStatus.values());
        FINDINGS_QUALITY.setNullRepresentation("");
        FINDINGS_TESTING.setNullRepresentation("");

        return new MVerticalLayout(
                new MFormLayout(
                        new MHorizontalLayout(
                                new MVerticalLayout(
                                        ISSUANCE_DATE,
                                        RFC_DATE,
                                        IDF,
                                        IMPORTER_NAME,
                                        HS_CODE,
                                        SERIAL_NUMBER,
                                        DATE_ADDED
                                ), new MVerticalLayout(
                                        EXPORTER_NAME,
                                        INSPECTION_DATE,
                                        PLACE_OF_INSPECTION,
                                        DESTINATION_PORT,
                                        INVOICE_NO,
                                        DATE_EDITED,
                                        EDITED_BY),
                                new MVerticalLayout(
                                        INVOICE_DATE,
                                        SHIPMENT_MODE,
                                        COUNTRY_OF_SUPPLY,
                                        FOB_VALUE,
                                        FOB_CURRENCY,
                                        DATE_APPROVED),
                                new MVerticalLayout(
                                        QUANTITY,
                                        PRODUCT_DESCRIPTION,
                                        STANDARD,
                                        STATUS,
                                        ADDED_BY,
                                        APPROVED_BY)
                        ).withFullWidth(),
                        FINDINGS_QUALITY,
                        FINDINGS_TESTING
                ).withFullWidth(),
                getToolbar()
        ).withStyleName(ValoTheme.LAYOUT_CARD);
    }

    @PostConstruct
    void init() {
        setEagerValidation(true);
    }

}
