/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.vaadin.spring.samples.security.shared;


import java.io.OutputStream;
import javax.annotation.PostConstruct;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.vaadin.spring.samples.security.shared.backend.Cocs;
import org.vaadin.spring.samples.security.shared.backend.CocsRepository;

/**
 *
 * @author BRAVOH05
 */
@Slf4j
@Component
public class Schedule {

    //@Scheduled(zone = "Africa/Nairobi", cron = "${cron.time}")
    public void scheduledTask() {

        log.info("=====Startin scheduled jobs=====");
//        String servletPath = VaadinServlet.getCurrent()
//                .getServletContext().getContextPath();
//        log.info("====="+servletPath+"=====");
    }
    
    @Autowired 
    CocsRepository cocsRepo;
    
    private JAXBContext jaxbContext;

    @PostConstruct
    void init() {
        try {
            jaxbContext = JAXBContext.newInstance(Cocs.class);
        } catch (JAXBException ex) {
            log.info(Schedule.class.getName(), ex);
        }
    }
    
    public void writeAsXml(Cocs cocs ,
        OutputStream ou) {
        cocs = cocsRepo.findCOCNO(cocs.getCOCNO());
        try {
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

            // output pretty printed
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,
                    true);
            jaxbMarshaller.marshal(cocs, ou);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }

    }
}
