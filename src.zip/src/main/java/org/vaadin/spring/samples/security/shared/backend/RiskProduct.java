/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.vaadin.spring.samples.security.shared.backend;

import java.io.Serializable;
import javax.annotation.Generated;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.security.core.userdetails.User;

/**
 *
 * @author BRAVOH05
 */
@Entity
@Table(name = "tb_risk_product")
public class RiskProduct implements Serializable {

    @Id
    @Getter
    @Setter
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Getter
    @Setter
    private String product_description;
    @Getter
    @Setter
    private String hscode;
    @Getter
    @Setter
    private String risk_level;
    
    @Getter
    @Setter
    @CreatedBy
    private User created_by;
    
    @Getter
    @Setter
    @CreatedDate
    private DateTime created_on;

}
