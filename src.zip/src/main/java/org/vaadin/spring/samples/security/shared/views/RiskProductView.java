package org.vaadin.spring.samples.security.shared.views;

import com.mysql.jdbc.StringUtils;
import com.vaadin.event.FieldEvents;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.server.FontAwesome;
import com.vaadin.shared.ui.MarginInfo;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.TextField;
import javax.annotation.PostConstruct;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.vaadin.spring.samples.security.shared.Common;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.vaadin.spring.samples.security.shared.Sections;
import org.vaadin.spring.samples.security.shared.backend.RiskProduct;
import org.vaadin.spring.samples.security.shared.backend.RiskProductRepository;
import org.vaadin.spring.samples.security.shared.backend.User_roles;
import org.vaadin.spring.samples.security.shared.backend.User_rolesRepository;
import org.vaadin.spring.samples.security.shared.backend.Users;
import org.vaadin.spring.samples.security.shared.backend.UsersRepository;
import org.vaadin.spring.sidebar.annotation.FontAwesomeIcon;
import org.vaadin.spring.sidebar.annotation.SideBarItem;
import org.vaadin.viritin.button.ConfirmButton;
import org.vaadin.viritin.button.MButton;
import org.vaadin.viritin.fields.MTable;
import org.vaadin.viritin.fields.MTextField;
import org.vaadin.viritin.label.Header;
import org.vaadin.viritin.layouts.MHorizontalLayout;
import org.vaadin.viritin.layouts.MVerticalLayout;
/*
*   @Author Bravoh05
*   @Description Expression object is undefined on line 36, column 20 in Templates/Entities/VaadinViritinSpringEntryView.java.EntryView
*
*
*/

@Secured({"ROLE_ACCOUNT", "ROLE_ADMIN","ROLE_RISK_MANAGER" })
@SpringView(name = "RiskProductView")
@SideBarItem(sectionId = Sections.VIEWS, caption = "Risk Product")
@FontAwesomeIcon(FontAwesome.LIFE_SAVER)
public class RiskProductView extends MVerticalLayout implements View {

    @Autowired
    RiskProductRepository repo;

    private final MTable<RiskProduct> list = new MTable<>(RiskProduct.class)     
            .withProperties("product_description","risk_level","hscode")
            .withColumnHeaders("product_description","risk_level","country")
            .setSortableProperties("product_description","risk_level","country")
            .withFullWidth();

    private final TextField filter = new MTextField();
    private final Button addNew = new MButton(FontAwesome.PLUS, this::add);
	private final Button edit = new MButton(FontAwesome.PENCIL_SQUARE_O, this::edit);
    private final Button delete = new ConfirmButton(FontAwesome.TRASH_O,
            "Are you sure you want to delete the entry?", this::remove);
    private final Header header = new Header("Risk Product Section").setHeaderLevel(2);

    private Common common = new Common();

    private User user;
    private Users userz;
    private User_roles user_role;

    @Autowired
    UsersRepository usersRepository;

    @Autowired
    User_rolesRepository userRoleRepo;
    
    @Override
    public void enter(ViewChangeListener.ViewChangeEvent viewChangeEvent) {
        listEntities();
    }

    @PostConstruct
    void init() {

        user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        userz = usersRepository.findCreator(user.getUsername());
        if (userz != null) {
            user_role = userRoleRepo.findRole(Long.parseLong(userz.getUserid().toString()));
        }

        filter.setInputPrompt("Search");
        filter.addTextChangeListener((FieldEvents.TextChangeEvent event) -> {
            listFilterEntities(event.getText());
        });
        add(
                new MVerticalLayout(
                        new MHorizontalLayout(header, addNew,edit, delete, filter)
                        .space().expand(header)
                        .alignAll(Alignment.MIDDLE_LEFT)
                )
        );
        expand(list);
        setMargin(new MarginInfo(false, true, true, true));
        list.addMValueChangeListener(e -> adjustActionButtonState());
    }

    protected void adjustActionButtonState() {
        boolean hasSelection = list.getValue() != null;
        delete.setEnabled(hasSelection);
    }

    static final int PAGESIZE = 45;

    private void listEntities() {
        list.setBeans(repo.findAll());
        adjustActionButtonState();
    }

    public void add(Button.ClickEvent clickEvent) {
        edit(new RiskProduct());
    }

    public void edit(Button.ClickEvent e) {
        edit(list.getValue());
    }

    public void remove(Button.ClickEvent e) {
        repo.delete(list.getValue());
        list.setValue(null);
        listEntities();
    }

    /*
     * @param filter search
     * 
     */
    public void listFilterEntities(String filterText) {

        if (StringUtils.isNullOrEmpty(filterText)) {
            list.setBeans(repo.findAll());
        } else {
//            list.setBeans(repo.findByNameStartsWithIgnoreCase(filterText));   
        }
         adjustActionButtonState();
    }

    protected void edit(final RiskProduct entry) {
        RiskProductEntryForm entryForm = new RiskProductEntryForm(entry);
        entryForm.openInModalPopup();
        entryForm.setSavedHandler(this::saveEntry);
        entryForm.setResetHandler(this::resetEntry);
    }

    public void saveEntry(RiskProduct entry) {
        repo.save(entry);
        listEntities();
        closeWindow();
    }

    public void resetEntry(RiskProduct entry) {
        listEntities();
        closeWindow();
    }

    protected void closeWindow() {
        getUI().getWindows().stream().forEach(w -> getUI().removeWindow(w));
    }
}