package org.vaadin.spring.samples.security.shared.backend;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author Duncan N
 */
public interface User_rolesRepository extends JpaRepository<User_roles, Integer> {

    User_roles findRole(@Param("roleId") Long roleId);
}
