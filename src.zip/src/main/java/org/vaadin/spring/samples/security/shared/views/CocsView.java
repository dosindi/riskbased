package org.vaadin.spring.samples.security.shared.views;

import com.mysql.jdbc.StringUtils;
import com.vaadin.event.FieldEvents;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Page;
import com.vaadin.shared.ui.MarginInfo;
import com.vaadin.shared.ui.datefield.Resolution;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.DateField;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Table;
import com.vaadin.ui.TextField;
import com.vaadin.ui.UI;
import com.vaadin.ui.themes.ValoTheme;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.vaadin.spring.samples.security.shared.Common;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.vaadin.spring.samples.security.shared.Schedule;
import org.vaadin.spring.samples.security.shared.Sections;
import org.vaadin.spring.samples.security.shared.backend.Cocs;
import org.vaadin.spring.samples.security.shared.backend.CocsRepository;
import org.vaadin.spring.samples.security.shared.backend.EntryStatus;
import org.vaadin.spring.samples.security.shared.backend.User_roles;
import org.vaadin.spring.samples.security.shared.backend.User_rolesRepository;
import org.vaadin.spring.samples.security.shared.backend.Users;
import org.vaadin.spring.samples.security.shared.backend.UsersRepository;
import org.vaadin.spring.sidebar.annotation.FontAwesomeIcon;
import org.vaadin.spring.sidebar.annotation.SideBarItem;
import org.vaadin.viritin.button.DownloadButton;
import org.vaadin.viritin.button.MButton;
import org.vaadin.viritin.fields.MTable;
import org.vaadin.viritin.fields.MTextField;
import org.vaadin.viritin.label.Header;
import org.vaadin.viritin.layouts.MHorizontalLayout;
import org.vaadin.viritin.layouts.MVerticalLayout;

/*
*   @Author Bravoh05
*   @Description CocsEntryView
*
*
 */
@Secured({"ROLE_SUPERVISOR", "ROLE_ADMIN", "ROLE_INSPECTOR"})
@SpringView(name = "COCs")
@SideBarItem(sectionId = Sections.VIEWS, caption = "COCs")
@FontAwesomeIcon(FontAwesome.ARCHIVE)
public class CocsView extends MVerticalLayout implements View {

    public static String VIEW_NAME = "COCs";

    @Autowired
    CocsRepository repo;

    private final Header header = new Header("COCs").setHeaderLevel(2);
    private final MTable<Cocs> list = new MTable<>(Cocs.class)
            .withProperties("IDF", "IMPORTER_NAME", "EXPORTER_NAME", "COUNTRY_OF_SUPPLY", "STATUS")
            .withColumnHeaders("IDF", "IMPORTER_NAME", "EXPORTER_NAME", "COUNTRY_OF_SUPPLY", "STATUS")
            .setSortableProperties("IDF", "IMPORTER_NAME", "EXPORTER_NAME", "COUNTRY_OF_SUPPLY", "STATUS")
            .withFullWidth();//"COCNO", "ISSUANCE_DATE", "RFC_DATE", "IDF", "IMPORTER_NAME", "EXPORTER_NAME", "INSPECTION_DATE", "PLACE_OF_INSPECTION", "DESTINATION_PORT", "SHIPMENT_MODE", "COUNTRY_OF_SUPPLY", "FOB_VALUE", "FOB_CURRENCY", "INVOICE_NO", "INVOICE_DATE", "HS_CODE", "QUANTITY", "PRODUCT_DESCRIPTION", "STANDARD", "FINDINGS_QUALITY", "FINDINGS_TESTING", "STATUS", "ADDED_BY", "EDITED_BY", "DATE_ADDED", "DATE_EDITED", "DATE_APPROVED", "APPROVED_BY"

    private final TextField filter = new MTextField();
    private final Button addNew = new MButton(FontAwesome.PLUS, this::add);
    private final Common common = new Common();
    private final Label lblfrom = new Label("From:");
    private final Label lblto = new Label("To:");
    private final DateField from = new DateField();
    private final DateField to = new DateField();
    private final Button search = new MButton(FontAwesome.SEARCH, this::search);

    private User user;
    private Users userz;
    private User_roles user_role;

    @Autowired
    UsersRepository usersRepository;

    @Autowired
    User_rolesRepository userRoleRepo;
    
    @Autowired
    Schedule schedule;

    @Override
    public void enter(ViewChangeListener.ViewChangeEvent viewChangeEvent) {
        //Display Pending
        if (user_role.getRole().equals("ROLE_SUPERVISOR")) {
//            List<Cocs> entries = repo.findStatus(EntryStatus.PENDING);
            List<Cocs> entries = repo.findStatusAssignedTo(EntryStatus.PENDING, userz);
            listEntities(entries);
        }
        //Display Approved
        if (user_role.getRole().equals("ROLE_DATA_ENTRY")) {
            List<Cocs> entries = repo.findStatus(EntryStatus.APPROVED);
            listEntities(entries);
        }
        //Display All
        if (user_role.getRole().equals("ROLE_ADMIN")) {
            listEntities(last1month());
        }
    }

    @PostConstruct
    void init() {

        Date last30days1 = common.last30days;

        from.setDateFormat("yyyy-MM-dd");
        from.setValue(last30days1);
        from.setResolution(Resolution.MINUTE);

        to.setDateFormat("yyyy-MM-dd");
        to.setValue(common.today);
        to.setResolution(Resolution.MINUTE);
        MHorizontalLayout dateFilter = new MHorizontalLayout();
        dateFilter.addComponents(lblfrom, from, lblto, to, search);

        user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        userz = usersRepository.findCreator(user.getUsername());
        if (userz != null) {
            user_role = userRoleRepo.findRole(Long.parseLong(userz.getUserid().toString()));
        }

        filter.setInputPrompt("Search");
        filter.addTextChangeListener((FieldEvents.TextChangeEvent event) -> {
            listFilterEntities(event.getText());
        });

        MHorizontalLayout vh = new MHorizontalLayout(header, addNew, filter)
                .space().expand(header)
                .alignAll(Alignment.MIDDLE_LEFT);
        //if role is supervisor
        if (user_role.getRole().equals("ROLE_SUPERVISOR")) {
            vh = new MHorizontalLayout(header, filter)
                    .space().expand(header)
                    .alignAll(Alignment.MIDDLE_LEFT);
        }
        add(
                new MVerticalLayout(
                        vh, dateFilter
                )
        );
        expand(list);
        setMargin(new MarginInfo(false, true, true, true));
        list.setStyleName(ValoTheme.TREETABLE_COMPACT);
        list.addGeneratedColumn("action", (Table source, Object itemId, Object columnId) -> {
            Cocs cocs = (Cocs) itemId;
            Button print = new MButton(FontAwesome.FILE_PDF_O);
            print.addClickListener((Button.ClickEvent event) -> {
                //https://secure-peak-20549.herokuapp.com/ipvqs
                Page.getCurrent().open("https://secure-peak-20549.herokuapp.com/ipvqs/reporto/pdf/PVQS_Certificate?param=" + cocs.getCOCNO(), "PRINT", Boolean.TRUE);

                new Notification("Printing... ", Notification.Type.TRAY_NOTIFICATION).show(Page.getCurrent());
            });
            Button modify = new MButton(FontAwesome.EDIT);
            modify.addClickListener((Button.ClickEvent e) -> {

                UI.getCurrent().getNavigator().navigateTo(CocsEntryFormView.VIEW_NAME + "/" + cocs.getCOCNO());
            });

            Button email = new DownloadButton(
                    out ->schedule.writeAsXml(cocs,out)).withIcon(FontAwesome.DOWNLOAD).withDescription("download xml");
//            System.out.println("+++++>" + cocs.getSTATUS());
            MHorizontalLayout h = new MHorizontalLayout();
            if (cocs.getSTATUS() == EntryStatus.APPROVED) {
                h.addComponents(print, email, modify);
            } else {
                h.addComponents(modify);
            }

            return h;
        });
    }

    static final int PAGESIZE = 45;

    private void listEntities(List<Cocs> entries) {
        list.setBeans(entries);
    }

    public void add(Button.ClickEvent clickEvent) {
        UI.getCurrent().getNavigator().navigateTo(CocsEntryFormView.VIEW_NAME);
    }

    public List<Cocs> last1month() {
        List<Cocs> entries = repo.findFromTo(common.last30days, common.kesho);
        return entries;
    }

    public void search(Button.ClickEvent e) {
        List<Cocs> entries = repo.findFromTo(from.getValue(), to.getValue());
        list.setBeans(entries);
    }

    /*
     * @param filter search
     * 
     */
    public void listFilterEntities(String filterText) {

        if (StringUtils.isNullOrEmpty(filterText)) {
            list.setBeans(repo.findAll());
        } else {
            list.setBeans(repo.findImporter(filterText));
        }
    }

}
