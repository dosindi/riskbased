package org.vaadin.spring.samples.security.shared.backend;

import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.vaadin.spring.samples.security.shared.backend.RiskImporter;

import org.springframework.stereotype.Repository;

/**
 *
 * @author Duncan N
 */
public interface RiskImporterRepository  extends JpaRepository<RiskImporter, Long> {

}