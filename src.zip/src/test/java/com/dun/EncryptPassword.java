/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dun;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

/**
 *
 * @author BRAVOH05
 */
public class EncryptPassword {

    public static void main(String args[]) {
        String encryptedPassword = new BCryptPasswordEncoder().encode("password");
        System.out.println("encrypted:" + encryptedPassword);
    }

}
