package org.vaadin.spring.samples.security.shared.backend;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author Duncan N
 */

public interface AuditLoginsRepository extends JpaRepository<AuditLogins, Long> {

    //@Query("SELECT p FROM INVOICE p WHERE p.TO IS NOT NULL")
    //List<Invoice> findByToNotNull();
    
    List<AuditLogins> findByUsernameStartsWithIgnoreCase(String filter);
}