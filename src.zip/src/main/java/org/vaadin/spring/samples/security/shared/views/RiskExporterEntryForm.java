package org.vaadin.spring.samples.security.shared.views;

import com.vaadin.ui.Component;
import com.vaadin.ui.DateField;
import com.vaadin.ui.TextField;
import com.vaadin.ui.themes.ValoTheme;
import javax.annotation.PostConstruct;
import org.vaadin.spring.samples.security.shared.backend.RiskExporter;
import org.vaadin.teemu.switchui.Switch;
import org.vaadin.viritin.fields.MTextField;
import org.vaadin.viritin.form.AbstractForm;
import org.vaadin.viritin.layouts.MFormLayout;
import org.vaadin.viritin.layouts.MVerticalLayout;

public class RiskExporterEntryForm extends AbstractForm<RiskExporter> {

    
      private final TextField id = new MTextField("id").withFullWidth();
      private final TextField exporter_name = new MTextField("Exporter Name").withFullWidth();
      private final TextField exporter_pin = new MTextField("Exporter Pin").withFullWidth();
      private final TextField address = new MTextField("Address").withFullWidth();
      private final TextField risk_level = new MTextField("Risk Level").withFullWidth();
      private final TextField country = new MTextField("Country").withFullWidth();

    //DateField birthDate = new DateField("Birth Day");
    //TypedSelect<RoleStatus> role = new TypedSelect().withCaption("Role");
    //Switch colleague = new Switch("ADMIN");

    RiskExporterEntryForm(RiskExporter entry) {
        setSizeUndefined();
        setEntity(entry);
    }

    @Override
    protected Component createContent() {
        return new MVerticalLayout(
                new MFormLayout(
                            id ,
                            exporter_name ,
                            exporter_pin ,
                            address ,
                            risk_level ,
                            country 
                ).withFullWidth(),
                getToolbar()
        ).withStyleName(ValoTheme.LAYOUT_CARD);
    }

    @PostConstruct
    void init() {
        setEagerValidation(true);
    }

}