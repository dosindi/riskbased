/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.vaadin.spring.samples.security.shared;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.ModelAndView;
import org.vaadin.spring.samples.security.shared.backend.Users;
import org.vaadin.spring.samples.security.shared.backend.UsersRepository;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author BRAVOH05
 */
@RestController
public class ActivateController {

    @Autowired
    SpringEmailService springEmailService;
    
    @Autowired
    UsersRepository usersRepository;

    @GET
    @Produces(MediaType.APPLICATION_XML)
    @RequestMapping("/activate")
    public List<Users> getUsers() {
        System.out.println("--testing::");
        return usersRepository.findAll();
    }

    @RequestMapping(path = "/reporto/{format}/{docn}", method = RequestMethod.GET)
    public ModelAndView getReporto(@PathVariable("format") String format,@RequestParam("param") String param,@PathVariable("docn") String docn  ) {
        Map<String, Object> parametros = new HashMap();
        parametros.put("format", format);
        parametros.put("cocno",param);
        return new ModelAndView(docn, parametros);
    }
    
     public void sendEmail(String to) {
        try {
            // all values as variables to clarify its usage
            InputStream inputStream = getClass().getResourceAsStream("/file.pdf");
            String from = "sender@test.com";
            String subject = "Your PDF";
            String text = "Here there is your <b>PDF</b> file!";
            String fileName = "file.pdf";
            String mimeType = "application/pdf";

            springEmailService.send(from, to, subject, text, inputStream, fileName, mimeType);

            inputStream.close();

           // Notification.show("Email sent");

        } catch (Exception e) {
            e.printStackTrace();
           // Notification.show("Error sending the email", Notification.Type.ERROR_MESSAGE);
        }
    }
}
