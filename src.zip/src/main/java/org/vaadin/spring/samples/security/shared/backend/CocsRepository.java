package org.vaadin.spring.samples.security.shared.backend;

import java.util.Date;
import java.util.List;
import javax.xml.bind.Marshaller;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import org.springframework.stereotype.Repository;

/**
 *
 * @author Duncan N
 */
@Repository
public interface CocsRepository extends JpaRepository<Cocs, Integer> {

    public Cocs findCOCNO(@Param("cocno") Long cocno);

    public List<Cocs> findFromTo(@Param("from") Date value, @Param("to") Date value0);

    public List<Cocs> findStatusFromTo(@Param("from") Date value, @Param("to") Date value0, @Param("status") EntryStatus entryStatus);

    public List<Cocs> findStatusAssignedTo(@Param("status") EntryStatus entryStatus, @Param("users") Users user);
    
    public List<Cocs> findStatus(@Param("status") EntryStatus entryStatus);

    public List<Cocs> findSubStatus(@Param("substatus") EntrySubStatus entryStatus);

    public List<Cocs> findStatusSubStatusFromTo(@Param("from") Date value, @Param("to") Date value0, @Param("status") EntryStatus entryStatus, @Param("substatus") EntrySubStatus entrySubStatus);

    public List<Cocs> findSubStatusFromTo(@Param("from") Date value, @Param("to") Date value0, @Param("substatus") EntrySubStatus entryStatus);

    public List<Cocs> findIDF(@Param("idf") String idf);

    public List<Cocs> findExporter(@Param("exporter") String exporter);

    public List<Cocs> findImporter(@Param("importer") String importer);

  
}
