/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.vaadin.spring.samples.security.shared.backend;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.repository.Temporal;
import org.springframework.security.core.userdetails.User;

/**
 *
 * @author BRAVOH05
 */
@Entity
@Table(name = "tb_risk_exporter")
public class RiskExporter implements Serializable {

    @Id
    @Getter
    @Setter
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Getter
    @Setter
    private String exporter_name;
    @Getter
    @Setter
    private String exporter_pin;
    @Getter
    @Setter
    private String address;
    @Getter
    @Setter
    private String risk_level;
    @Getter
    @Setter
    private String country;

    @Getter
    @Setter
    @Column(name = "created_by")
    @CreatedBy
    private User created_by;

    @Getter
    @Setter
    @Column(name = "created_on")
//    @Temporal(value = TemporalType.TIMESTAMP)
    @CreatedDate
    private Date created_on;

}
