package org.vaadin.spring.samples.security.shared.views;

import com.mysql.jdbc.StringUtils;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.server.ExternalResource;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Page;
import com.vaadin.server.UserError;
import com.vaadin.shared.ui.BorderStyle;
import com.vaadin.shared.ui.MarginInfo;
import com.vaadin.spring.annotation.SpringView;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.DateField;
import com.vaadin.ui.Label;
import com.vaadin.ui.Link;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;
import com.vaadin.ui.TextArea;
import com.vaadin.ui.TextField;
import com.vaadin.ui.UI;
import com.vaadin.ui.Upload;
import com.vaadin.ui.Upload.Receiver;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.vaadin.spring.samples.security.shared.Common;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.vaadin.spring.samples.security.shared.Sections;
import org.vaadin.spring.samples.security.shared.backend.Cocs;
import org.vaadin.spring.samples.security.shared.backend.CocsRepository;
import org.vaadin.spring.samples.security.shared.backend.EntryStatus;
import org.vaadin.spring.samples.security.shared.backend.EntrySubStatus;
import org.vaadin.spring.samples.security.shared.backend.PackingStatus;
import org.vaadin.spring.samples.security.shared.backend.User_roles;
import org.vaadin.spring.samples.security.shared.backend.User_rolesRepository;
import org.vaadin.spring.samples.security.shared.backend.Users;
import org.vaadin.spring.samples.security.shared.backend.UsersRepository;
import org.vaadin.spring.sidebar.annotation.FontAwesomeIcon;
import org.vaadin.spring.sidebar.annotation.SideBarItem;
import org.vaadin.viritin.button.MButton;
import org.vaadin.viritin.fields.MTextArea;
import org.vaadin.viritin.fields.MTextField;
import org.vaadin.viritin.label.Header;
import org.vaadin.viritin.label.MLabel;
import org.vaadin.viritin.layouts.MHorizontalLayout;
import org.vaadin.viritin.layouts.MVerticalLayout;

/*
*   @Author Bravoh05
*   @Description CocsEntryFormView
*
*
 */
@Secured({"ROLE_SUPERVISOR", "ROLE_ADMIN", "ROLE_DATA_ENTRY", "ROLE_SUPERVISOR", "ROLE_INSPECTOR"})
@SpringView(name = "CocsEntryFormView")
@SideBarItem(sectionId = Sections.VIEWS, caption = "Add COCs")
@FontAwesomeIcon(FontAwesome.ADN)
public class CocsEntryFormView extends CssLayout implements View {

    public static String VIEW_NAME = "CocsEntryFormView";

    @Autowired
    User_rolesRepository repo;

    private Label header = new MLabel("Edit COC");
    private final Button save = new MButton(FontAwesome.SAVE, this::save).withWidth("140px");
    private final Button cancel = new MButton(FontAwesome.ARROW_LEFT, this::reset).withWidth("140px").withStyleName(ValoTheme.BUTTON_SMALL);

    private final Button save1 = new MButton(FontAwesome.SAVE, this::save).withWidth("140px").withStyleName(ValoTheme.BUTTON_SMALL);
    private final Button cancel1 = new MButton(FontAwesome.ARROW_LEFT, this::reset).withWidth("140px").withStyleName(ValoTheme.BUTTON_SMALL);

    public final Label COCNO = new Label("#");
    public final TextField IDF = new MTextField("IDF").withFullWidth();
    public final TextArea IMPORTER_NAME = new MTextArea("IMPORTER_NAME").withFullWidth();
    public final TextArea EXPORTER_NAME = new MTextArea("EXPORTER_NAME").withFullWidth();

    public final TextArea SUPERVISOR_REMARKS = new MTextArea("SUPERVISOR_REMARKS").withFullWidth();

    public final DateField INSPECTION_DATE = new DateField("INSPECTION_DATE");
    public final TextField PLACE_OF_INSPECTION = new MTextField("PLACE_OF_INSPECTION").withFullWidth();
    public final TextField DESTINATION_PORT = new MTextField("DESTINATION_PORT").withFullWidth();
    public final TextField SHIPMENT_MODE = new MTextField("SHIPMENT_MODE").withFullWidth();
    public final TextField COUNTRY_OF_SUPPLY = new MTextField("COUNTRY_OF_SUPPLY").withFullWidth();
    public final TextField FOB_VALUE = new MTextField("FOB_VALUE").withFullWidth();
    public final TextField FOB_CURRENCY = new MTextField("FOB_CURRENCY").withFullWidth();
    public final TextField INVOICE_NO = new MTextField("INVOICE_NO").withFullWidth();
    public final DateField INVOICE_DATE = new DateField("INVOICE_DATE");
    public final TextField HS_CODE = new MTextField("HS_CODE").withFullWidth();
    public final TextField QUANTITY = new MTextField("QUANTITY").withFullWidth();
    public final TextField PRODUCT_DESCRIPTION = new MTextField("PRODUCT_DESCRIPTION").withFullWidth();
    public final TextField STANDARD = new MTextField("STANDARD").withFullWidth();
    public final TextArea FINDINGS_QUALITY = new TextArea("FINDINGS_QUALITY");
    public final TextArea FINDINGS_TESTING = new TextArea("FINDINGS_TESTING");
    public final ComboBox STATUS = new ComboBox("STATUS");
    public final ComboBox SUBSTATUS = new ComboBox("SUBSTATUS");
    public final ComboBox PACKINGSTATUS = new ComboBox("PACKING DETAILS:");
    public final ComboBox ASSIGN_INSPECTOR = new ComboBox("ASSIGN INSPECTOR");
    public final MLabel ADDED_BY = new MLabel("ADDED_BY").withFullWidth();
    public final MLabel EDITED_BY = new MLabel("EDITED_BY").withFullWidth();
    public final MLabel DATE_ADDED = new MLabel("DATE_ADDED").withFullWidth();
    public final MLabel DATE_EDITED = new MLabel("DATE_EDITED").withFullWidth();
    public final Label DATE_APPROVED = new MLabel("DATE_APPROVED").withFullWidth();
    public final MLabel APPROVED_BY = new MLabel("APPROVED_BY").withFullWidth();

    VerticalLayout uploadsLayout = new MVerticalLayout();

    ImageUploader uploadReceiver = new ImageUploader();

    Upload UPLOAD_TEST_RESULTS = new Upload("UPLOAD TEST_RESULTS", (Upload.Receiver) uploadReceiver);

    Upload UPLOAD_INSPECTION_REPORT = new Upload("UPLOAD INSPECTION_REPORT", (Upload.Receiver) uploadReceiver);

    String tag = "";

    private final Common common = new Common();
    private Cocs selectedCoc;
    private User user;
    private Users userz;
    private User_roles user_role;

    @Autowired
    UsersRepository usersRepository;

    @Autowired
    User_rolesRepository userRoleRepo;

    @Autowired
    CocsRepository cocRepo;
    public List<Users> inspectors = null;

    @Override
    public void enter(ViewChangeListener.ViewChangeEvent event) {
        if (event.getParameters() != null && !"".equals(event.getParameters())
                && !StringUtils.isNullOrEmpty(event.getParameters())) {
            //Populate form for Edit
            long cocId = Long.parseLong(event.getParameters());

            selectedCoc = cocRepo.findCOCNO(cocId);

            if (selectedCoc.getSTATUS() == EntryStatus.APPROVED) {
                setReadOnly();
            }

            try {

                System.out.println("----" + selectedCoc.getUPLOAD_INSPECTION_REPORT().contains(","));
                if (!selectedCoc.getUPLOAD_INSPECTION_REPORT().contains(",")) {
                    Link link = new Link(selectedCoc.getUPLOAD_INSPECTION_REPORT(), new ExternalResource(common.dirName + "/" + selectedCoc.getUPLOAD_INSPECTION_REPORT()),
                            "_top", 500, 350, BorderStyle.DEFAULT);
                    uploadsLayout.addComponent(link);
                } else if (selectedCoc.getUPLOAD_INSPECTION_REPORT().contains(",")) {

                    String[] split = selectedCoc.getUPLOAD_TEST_RESULTS().split(",");
                    for (int i = 0; i < split.length; i++) {

                        Link link = new Link(split[i], new ExternalResource(common.dirName + "/" + split[i]),
                                "_top", 500, 350, BorderStyle.DEFAULT);
                        uploadsLayout.addComponent(link);
                    }

                }
            } catch (NullPointerException e) {

                uploadsLayout.addComponent(new Label("No Uploads"));
            }
            COCNO.setValue("PVQS/COC/" + String.valueOf(selectedCoc.getCOCNO()));

            IDF.setValue(selectedCoc.getIDF());

            IMPORTER_NAME.setValue(selectedCoc.getIMPORTER_NAME());

            EXPORTER_NAME.setValue(selectedCoc.getEXPORTER_NAME());

            INSPECTION_DATE.setValue(selectedCoc.getINSPECTION_DATE());

            PLACE_OF_INSPECTION.setValue(selectedCoc.getPLACE_OF_INSPECTION());

            DESTINATION_PORT.setValue(selectedCoc.getDESTINATION_PORT());

            SHIPMENT_MODE.setValue(selectedCoc.getSHIPMENT_MODE());

            COUNTRY_OF_SUPPLY.setValue(selectedCoc.getCOUNTRY_OF_SUPPLY());

            FOB_VALUE.setValue(selectedCoc.getFOB_VALUE() + "");

            FOB_CURRENCY.setValue(selectedCoc.getFOB_CURRENCY());

            INVOICE_NO.setValue(selectedCoc.getINVOICE_NO());

            INVOICE_DATE.setValue(selectedCoc.getINVOICE_DATE());

            HS_CODE.setValue(selectedCoc.getHS_CODE());

            QUANTITY.setValue(selectedCoc.getQUANTITY());

            PRODUCT_DESCRIPTION.setValue(selectedCoc.getPRODUCT_DESCRIPTION());

            STANDARD.setValue(selectedCoc.getSTANDARD());

            FINDINGS_QUALITY.setValue(selectedCoc.getFINDINGS_QUALITY());

            FINDINGS_TESTING.setValue(selectedCoc.getFINDINGS_TESTING());

            STATUS.setValue(selectedCoc.getSTATUS());

            ASSIGN_INSPECTOR.setValue(selectedCoc.getASSIGNED_INSPECTOR());
            
            SUBSTATUS.setValue(selectedCoc.getSUBSTATUS());
            
            PACKINGSTATUS.setValue(selectedCoc.getPACKING_DETAILS());

            try {
                ADDED_BY.setValue(selectedCoc.getADDED_BY().getFullname());
            } catch (NullPointerException e) {
                System.out.println("--->");
            }
            EDITED_BY.setValue(selectedCoc.getEDITED_BY().getFullname());

            DATE_ADDED.setValue(selectedCoc.getDATE_ADDED() + "");

            DATE_EDITED.setValue(selectedCoc.getDATE_EDITED() + "");

            DATE_APPROVED.setValue(selectedCoc.getDATE_APPROVED() + "");

            APPROVED_BY.setValue(selectedCoc.getAPPROVED_BY().getFullname());

            SUPERVISOR_REMARKS.setValue(selectedCoc.getSUPERVISOR_REMARKS());

        } else {
            //Add New Cocs
            header.setValue("Add COCs");

        }
    }

    @PostConstruct
    void init() {

        user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        userz = usersRepository.findCreator(user.getUsername());
        if (userz != null) {
            user_role = userRoleRepo.findRole(Long.parseLong(userz.getUserid().toString()));
        }
        FINDINGS_TESTING.setWidth("90%");
        FINDINGS_QUALITY.setWidth("90%");
        FINDINGS_TESTING.setRows(5);
        FINDINGS_QUALITY.setRows(5);

        header.addStyleName(ValoTheme.LABEL_H2);

        SUBSTATUS.addItems(EntrySubStatus.values());
        PACKINGSTATUS.addItems(PackingStatus.values());

        inspectors = usersRepository.findAll();
        ASSIGN_INSPECTOR.addItems(inspectors);

        save.addStyleName(ValoTheme.BUTTON_FRIENDLY);
        save.addStyleName(ValoTheme.BUTTON_SMALL);
        cancel.addStyleName(ValoTheme.BUTTON_PRIMARY);
        cancel.addStyleName(ValoTheme.BUTTON_SMALL);
        save1.addStyleName(ValoTheme.BUTTON_FRIENDLY);
        cancel1.addStyleName(ValoTheme.BUTTON_PRIMARY);
        save1.addStyleName(ValoTheme.BUTTON_SMALL);
        cancel1.addStyleName(ValoTheme.BUTTON_SMALL);

        addStyleName(ValoTheme.MENU_PART);
        setWidth("100%");
        setHeight("100%");

        VerticalLayout layout = new MVerticalLayout();
        VerticalLayout layout1 = new MVerticalLayout();

        if (user_role.getRole().equals(common.ROLE_DATA_ENTRY)) {
            STATUS.setEnabled(false);
            SUBSTATUS.setEnabled(false);
        }
        if (user_role.getRole().equals(common.ROLE_INSPECTOR)) {
            STATUS.addItems(EntryStatus.PENDING, EntryStatus.SEND_TO_SUPERVISOR);
            layout.addComponents(
                    UPLOAD_TEST_RESULTS,
                    UPLOAD_INSPECTION_REPORT,
                    INSPECTION_DATE,
                    SUPERVISOR_REMARKS
            );
            buildUploads();
            SUPERVISOR_REMARKS.setEnabled(false);
            layout1.addComponents(FINDINGS_TESTING, FINDINGS_QUALITY);
        }
        if (user_role.getRole().equals(common.ROLE_SUPERVISOR)) {
            STATUS.addItems(EntryStatus.APPROVED, EntryStatus.DEFFERED);

            layout.addComponents(                    
                    ASSIGN_INSPECTOR,
                    SUPERVISOR_REMARKS,
                    uploadsLayout
            );

        }
        if (user_role.getRole().equals(common.ROLE_ADMIN)) {

            layout.addComponents(DATE_ADDED,
                    DATE_EDITED,
                    EDITED_BY,
                    DATE_APPROVED,
                    ADDED_BY,
                    APPROVED_BY,
                    SUPERVISOR_REMARKS,
                    UPLOAD_TEST_RESULTS,
                    UPLOAD_INSPECTION_REPORT
            );

            buildUploads();
        }

        MVerticalLayout v = new MVerticalLayout();
        v.addComponent(
                new MVerticalLayout(
                        new MHorizontalLayout(header, cancel, save)
                        .space().expand(header)
                        .alignAll(Alignment.MIDDLE_LEFT),
                        new MHorizontalLayout(
                                new MVerticalLayout(
                                        COCNO,
                                        IDF,
                                        IMPORTER_NAME
                                ), new MVerticalLayout(
                                        DESTINATION_PORT,
                                        COUNTRY_OF_SUPPLY,
                                        new MHorizontalLayout(INVOICE_NO, INVOICE_DATE).withFullWidth(),
                                        EXPORTER_NAME
                                )).withFullWidth(),
                        new MHorizontalLayout(new MVerticalLayout(
                                PLACE_OF_INSPECTION,
                                SHIPMENT_MODE,
                                FOB_VALUE,
                                FOB_CURRENCY,
                                HS_CODE,
                                QUANTITY,
                                PRODUCT_DESCRIPTION),
                                new MVerticalLayout(
                                        STANDARD, STATUS, SUBSTATUS, PACKINGSTATUS,
                                        layout)).withFullWidth(),
                        layout1, new MHorizontalLayout(new Header(""), cancel1, save1).alignAll(Alignment.MIDDLE_RIGHT)
                )
        );
        v.setMargin(new MarginInfo(false, true, true, true));
        addComponent(v);

        setStyle();
    }

    void save(Button.ClickEvent e) {

        boolean validated = isValidate();
        if (validated) {
            try {
                Cocs entry = new Cocs();
                //Add New
                if (COCNO.getValue().equals("#")) {
                    entry.setADDED_BY(userz);
                    entry.setSTATUS(EntryStatus.PENDING);

                }
                //Edit
                if (!COCNO.getValue().equals("#")) {
                    entry.setCOCNO(selectedCoc.getCOCNO());
                }

                entry.setAPPROVED_BY(userz);
                entry.setCOUNTRY_OF_SUPPLY(COUNTRY_OF_SUPPLY.getValue());
                entry.setDATE_ADDED(new Date());
                entry.setDATE_APPROVED(new Date());
                entry.setDATE_EDITED(new Date());
                entry.setDESTINATION_PORT(DESTINATION_PORT.getValue());
                entry.setEDITED_BY(userz);
                entry.setEXPORTER_NAME(EXPORTER_NAME.getValue());
                entry.setFINDINGS_QUALITY(FINDINGS_QUALITY.getValue());
                entry.setFINDINGS_TESTING(FINDINGS_TESTING.getValue());
                entry.setFOB_CURRENCY(FOB_CURRENCY.getValue());
                entry.setFOB_VALUE(Integer.parseInt(FOB_VALUE.getValue()));
                entry.setHS_CODE(HS_CODE.getCaption());
                entry.setIDF(IDF.getValue());
                entry.setIMPORTER_NAME(IMPORTER_NAME.getValue());
                entry.setINSPECTION_DATE(INSPECTION_DATE.getValue());
                entry.setINVOICE_DATE(INVOICE_DATE.getValue());
                entry.setINVOICE_NO(INVOICE_NO.getCaption());
                entry.setPLACE_OF_INSPECTION(PLACE_OF_INSPECTION.getValue());
                entry.setPRODUCT_DESCRIPTION(PRODUCT_DESCRIPTION.getValue());
                entry.setQUANTITY(QUANTITY.getValue());
                entry.setSHIPMENT_MODE(SHIPMENT_MODE.getValue());
                entry.setSTANDARD(STANDARD.getValue());

                if ((EntryStatus) STATUS.getValue() == null) {
                    entry.setSTATUS(EntryStatus.PENDING);
                } else {
                    entry.setSTATUS((EntryStatus) STATUS.getValue());
                }
                entry.setASSIGNED_INSPECTOR((Users) ASSIGN_INSPECTOR.getValue());
                entry.setSUBSTATUS((EntrySubStatus) SUBSTATUS.getValue());
                entry.setPACKING_DETAILS((PackingStatus) PACKINGSTATUS.getValue());

                if (user_role.getRole().equals(common.ROLE_SUPERVISOR)) {

                    //Save uploads
                    entry.setSUPERVISOR_REMARKS(SUPERVISOR_REMARKS.getValue());
                    entry.setAPPROVED_BY(userz);

                    if ((EntryStatus) STATUS.getValue() == EntryStatus.APPROVED) {
                        entry.setDATE_APPROVED(new Date());
                    }
                }
                if (user_role.getRole().equals(common.ROLE_INSPECTOR)) {
                    entry.setUPLOAD_INSPECTION_REPORT(UPLOAD_INSPECTION_REPORT.getCaption());
                    entry.setUPLOAD_TEST_RESULTS(UPLOAD_TEST_RESULTS.getCaption());

                }

                Cocs c = cocRepo.save(entry);

                if (c != null) {
                    UI.getCurrent().getNavigator().navigateTo(CocsView.VIEW_NAME);
                }
            } catch (NumberFormatException ex) {
                ex.printStackTrace();
                new Notification(new Common().MESSAGE, "*Input required", Notification.Type.ERROR_MESSAGE).show(UI.getCurrent().getPage());

            }
        }

    }

    void reset(Button.ClickEvent e) {
        UI.getCurrent().getNavigator().navigateTo(CocsView.VIEW_NAME);

    }

    private boolean isValidate() {
        boolean b = true;
        try {
            //VALIDATION
            if (StringUtils.isNullOrEmpty(COCNO.getValue())) {
                COCNO.setComponentError(new UserError("*Required COCNO"));
                b = false;
            }
            if (StringUtils.isNullOrEmpty(IDF.getValue())) {
                IDF.setComponentError(new UserError("*Required IDF"));
                b = false;
            }

            if (StringUtils.isNullOrEmpty(IMPORTER_NAME.getValue())) {
                IMPORTER_NAME.setComponentError(new UserError("*Required IMPORTER_NAME"));
                b = false;
            }
            if (StringUtils.isNullOrEmpty(EXPORTER_NAME.getValue())) {
                EXPORTER_NAME.setComponentError(new UserError("*Required EXPORTER_NAME"));
                b = false;
            }
            if (StringUtils.isNullOrEmpty(PLACE_OF_INSPECTION.getValue())) {
                PLACE_OF_INSPECTION.setComponentError(new UserError("*Required PLACE_OF_INSPECTION"));
                b = false;
            }
            if (StringUtils.isNullOrEmpty(DESTINATION_PORT.getValue())) {
                DESTINATION_PORT.setComponentError(new UserError("*Required DESTINATION_PORT"));
                b = false;
            }
            if (StringUtils.isNullOrEmpty(SHIPMENT_MODE.getValue())) {
                SHIPMENT_MODE.setComponentError(new UserError("*Required SHIPMENT_MODE"));
                b = false;
            }
            if (StringUtils.isNullOrEmpty(COUNTRY_OF_SUPPLY.getValue())) {
                COUNTRY_OF_SUPPLY.setComponentError(new UserError("*Required COUNTRY_OF_SUPPLY"));
                b = false;
            }
            if (StringUtils.isNullOrEmpty(FOB_VALUE.getValue())) {
                FOB_VALUE.setComponentError(new UserError("*Required FOB_VALUE"));
                b = false;
            }
            if (StringUtils.isNullOrEmpty(FOB_CURRENCY.getValue())) {
                FOB_CURRENCY.setComponentError(new UserError("*Required FOB_CURRENCY"));
                b = false;
            }
            if (StringUtils.isNullOrEmpty(INVOICE_NO.getValue())) {
                INVOICE_NO.setComponentError(new UserError("*Required INVOICE_NO"));
                b = false;
            }
            if (StringUtils.isNullOrEmpty(INVOICE_DATE.getValue().toString())) {
                INVOICE_DATE.setComponentError(new UserError("*Required INVOICE_DATE"));
                b = false;
            }
            if (StringUtils.isNullOrEmpty(HS_CODE.getValue())) {
                HS_CODE.setComponentError(new UserError("*Required HS_CODE"));
                b = false;
            }
            if (StringUtils.isNullOrEmpty(QUANTITY.getValue())) {
                QUANTITY.setComponentError(new UserError("*Required QUANTITY"));
                b = false;
            }
            if (StringUtils.isNullOrEmpty(PRODUCT_DESCRIPTION.getValue())) {
                PRODUCT_DESCRIPTION.setComponentError(new UserError("*Required PRODUCT_DESCRIPTION"));
                b = false;
            }
            if (StringUtils.isNullOrEmpty(STANDARD.getValue())) {
                STANDARD.setComponentError(new UserError("*Required STANDARD"));
                b = false;
            }

        } catch (NullPointerException e) {
            b = false;
        }

        return b;
    }

    private void buildUploads() {

        //UPLOADS
        UPLOAD_TEST_RESULTS.setId("result");
        UPLOAD_TEST_RESULTS.setButtonCaption("Upload Results");
        UPLOAD_TEST_RESULTS.setIcon(FontAwesome.UPLOAD);
        UPLOAD_TEST_RESULTS.addSucceededListener((Upload.SucceededListener) uploadReceiver);

        UPLOAD_INSPECTION_REPORT.setId("report");
        UPLOAD_INSPECTION_REPORT.setButtonCaption("Upload Report");
        UPLOAD_INSPECTION_REPORT.setIcon(FontAwesome.UPLOAD);
        UPLOAD_INSPECTION_REPORT.addSucceededListener((Upload.SucceededListener) uploadReceiver);

    }

    private void setStyle() {
        addStyleName("compact");
        Page.Styles styles = Page.getCurrent().getStyles();
        styles.add(".compact .v-textfield{border:solid;height:30px;border-color:#1b87e3;}");
        styles.add(".compact .v-textarea{border:solid;border-color:#1b87e3;}");
        styles.add(".compact .v-datefield{border:solid;height:30px;border-color:#1b87e3;}");
    }

    private void setReadOnly() {
        save.setEnabled(false);
        save1.setEnabled(false);
        COCNO.setEnabled(false);
        IDF.setEnabled(false);
        IMPORTER_NAME.setEnabled(false);
        EXPORTER_NAME.setEnabled(false);
        INSPECTION_DATE.setEnabled(false);
        PLACE_OF_INSPECTION.setEnabled(false);
        DESTINATION_PORT.setEnabled(false);
        SHIPMENT_MODE.setEnabled(false);
        COUNTRY_OF_SUPPLY.setEnabled(false);
        FOB_VALUE.setEnabled(false);
        FOB_CURRENCY.setEnabled(false);
        INVOICE_NO.setEnabled(false);
        INVOICE_DATE.setEnabled(false);
        HS_CODE.setEnabled(false);
        QUANTITY.setEnabled(false);
        PRODUCT_DESCRIPTION.setEnabled(false);
        STANDARD.setEnabled(false);
        FINDINGS_QUALITY.setEnabled(false);
        FINDINGS_TESTING.setEnabled(false);
        STATUS.setEnabled(false);
        ADDED_BY.setEnabled(false);
        EDITED_BY.setEnabled(false);
        DATE_ADDED.setEnabled(false);
        DATE_EDITED.setEnabled(false);
        DATE_APPROVED.setEnabled(false);
        APPROVED_BY.setEnabled(false);
        PACKINGSTATUS.setEnabled(false);
    }

    class ImageUploader implements Receiver, Upload.SucceededListener {

        public File oldfile;
        public File newfile;
        private static final long serialVersionUID = 1L;

        @Override
        public OutputStream receiveUpload(String filename, String mimeType) {
            // Create upload stream
            FileOutputStream fos = null;

            System.out.println("dir:" + common.dirName);
            String imageformat = filename.substring(filename.length() - 3,
                    filename.length());
            tag = "";
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy_mm_dd_ss");

            Date date = new Date();
            tag = "TEST_RESULTS" + sdf.format(date);
            try {

                oldfile = new File(common.dirName + filename);
                newfile = new File(common.dirName + tag + "." + imageformat);
                oldfile.renameTo(newfile);

                System.out.println(oldfile.getName() + "::newfile:"
                        + newfile.getName());
                tag = newfile.getName();
                if (!newfile.exists()) {
                    fos = new FileOutputStream(newfile);
                } else {
                    Notification.show("File Exists<br/>",
                            "Please choose another date",
                            Type.ERROR_MESSAGE);
                }
            } catch (final IOException e) {
                Notification.show("Could not open file<br/>",
                        e.getMessage(), Type.TRAY_NOTIFICATION);
                return null;
            }
            return fos;
        }

        @Override
        public void uploadSucceeded(Upload.SucceededEvent event) {

            if ("report".equals(event.getUpload().getId())) {
                String string = "";
                if (UPLOAD_INSPECTION_REPORT.getCaption().equals("UPLOAD INSPECTION_REPORT")) {
                    string = tag;
                } else {
                    string = UPLOAD_INSPECTION_REPORT.getCaption() + "," + tag;
                }
                UPLOAD_INSPECTION_REPORT.setCaptionAsHtml(true);
                UPLOAD_INSPECTION_REPORT.setCaption(string);
                UPLOAD_INSPECTION_REPORT.setIcon(FontAwesome.CHECK_SQUARE);
            }

            if ("result".equals(event.getUpload().getId())) {
                String string = "";
                if (UPLOAD_TEST_RESULTS.getCaption().equals("UPLOAD TEST_RESULTS")) {
                    string = tag;
                } else {
                    string = UPLOAD_TEST_RESULTS.getCaption() + "," + tag;
                }
                UPLOAD_TEST_RESULTS.setCaptionAsHtml(true);
                UPLOAD_TEST_RESULTS.setCaption(string);
                UPLOAD_TEST_RESULTS.setIcon(FontAwesome.CHECK_SQUARE);
            }

        }

    }

}
