package org.vaadin.spring.samples.security.shared.backend;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author Duncan N
 */
public interface EntryRepository extends JpaRepository<Entry, Long> {

    @Modifying
    @Transactional
    @Query("UPDATE Entry c SET c.status=:state WHERE c.fileName=:filename")
    Integer updateStatus(@Param("state") Entry.FileStatus status, @Param("filename") String filename);
}
