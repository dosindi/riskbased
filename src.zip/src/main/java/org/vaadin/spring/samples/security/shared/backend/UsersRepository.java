package org.vaadin.spring.samples.security.shared.backend;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Duncan N
 */
@Repository
public interface UsersRepository extends JpaRepository<Users, Long> {

    Users findCreator(@Param("filter") String filter);

    public List<Users> findByFullnameStartsWithIgnoreCase(String filterText);
    
    
}