/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.vaadin.spring.samples.security.shared.backend;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author BRAVOH05
 */
@Entity
@Table(name = "tb_entry")
//@NamedQueries({
//    @NamedQuery(name = "Entry.updateStatus", query ="UPDATE Entry c SET c.status=:state WHERE c.fileName=:filename")})
public class Entry implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

//    @Column(unique = true)
    private String fileName;

    private FileStatus status;

    private Date createdOn;

    public long getId() {
        return this.id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * @return the status
     */
    public FileStatus getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(FileStatus status) {
        this.status = status;
    }

    /**
     * @return the createdOn
     */
    public Date getCreatedOn() {
        return createdOn;
    }

    /**
     * @param createdOn the createdOn to set
     */
    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    public enum FileStatus {
        TOBEPROCESSED, PROCESSED, UNPROCESSED
    }
}
