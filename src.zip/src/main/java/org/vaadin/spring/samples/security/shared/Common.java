/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.vaadin.spring.samples.security.shared;

import com.vaadin.server.FileDownloader;
import com.vaadin.server.StreamResource;
import com.vaadin.ui.Button;
import com.vaadin.ui.Calendar;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.sf.jasperreports.engine.JRException;
import org.jfree.util.Log;

/**
 *
 * @author BRAVOH05
 */
public class Common {
    
    public String MESSAGE = "Message";
    
    public String appname = "PVQS";
    public String ROLE_ADMIN = "ROLE_ADMIN";
    public String ROLE_DATA_ENTRY = "ROLE_DATA_ENTRY";
    public String ROLE_SUPERVISOR = "ROLE_SUPERVISOR";
    public String ROLE_INSPECTOR = "ROLE_INSPECTOR";
    public String ROLE_RISK_MANAGER = "ROLE_RISK_MANAGER";
    
    public Random ran = new Random();
    public static final String driver = "org.postgresql.Driver";//com.mysql.jdbc.Driver
    public static final String ip = "";//localhost"10.10.1.241";
    public static final String username = "evyolyuzxncnrl";//root
    public static final String pass = "1eaf6a951c656a25a6973c5aaa5ca7d2145fb781c128fe2b490da2734aa186aa";//cello123"rootkebsqa2030";cello123
    public static final String port = "";//3306"3307"
    public static final String url = "jdbc:postgresql://ec2-54-221-234-62.compute-1.amazonaws.com:5432/d9d5vkiu46euoq?user=evyolyuzxncnrl&password=1eaf6a951c656a25a6973c5aaa5ca7d2145fb781c128fe2b490da2734aa186aa";
    public String dirName = "C:\\PORTER\\uploads\\";
    
    public Common() {
    }
    
    public Date today = new Date();
    public Date jana = new Date(today.getTime() - (1000 * 60 * 60 * 24 * 1));
    public Date kesho = new Date(today.getTime() + (1000 * 60 * 60 * 24 * 1));
    public Date last30days = new Date(today.getTime()
            + (1000 * 60 * 60 * 24 * 30));
    
    public String today_str = date2String(today);
    public String last30days_str = date2String(last30days);
    
    Calendar cal = new Calendar();
    public static final DateFormat DATEFORMAT = new SimpleDateFormat(
            "MM/dd/yyyy hh:mm:ss a");
    
    public int getRandom() {
        int r = ran.nextInt(1000);
        return r;
    }
    
    public double doubleRounder(double value, int places) {
        if (places < 0) {
            throw new IllegalArgumentException();
        }
        
        BigDecimal bd = new BigDecimal(Double.toString(value));
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        
        return bd.doubleValue();
        
    }
    
    public String date2String(Date date) {
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String string = sdf.format(date);
        // System.out.println(">>IN:" + date.toString() + " OUT:" + string);
        return string;
        
    }

    //Base path for report template
    private String baseReportsPath = "https://secure-peak-20549.herokuapp.com/ipvqs/VAADIN/themes/valo/";//"C:\\PORTER\\reports/";
//    private String baseReportsPath = VaadinService.getCurrent().getBaseDirectory().getAbsolutePath() + "/VAADIN/reports/";
//    private String baseReportsPath = "H:\\CLONE\\vaadin\\vaadin4spring\\samples\\security-sample-shared\\src\\main\\resources";

    /**
     * Get database connection, call report generation method and export's
     * report to Vaadin's FileDownloader
     *
     * @param reportTemplate Report template file name
     * @param reportOutputFilename Pdf output file name
     * @param buttonToExtend Vaadin button to extend
     */
    public void prepareForPdfReport(String reportTemplate,
            String reportOutputFilename, Button buttonToExtend) {
        System.out.println("Generating report...");
        Connection conn;
        try {
            conn = ConnectionHelper.getConnection();
            reportOutputFilename += ("_" + getDateAsString() + ".pdf");
            StreamResource myResource
                    = createPdfResource(conn,
                            reportTemplate, reportOutputFilename);
            FileDownloader fileDownloader = new FileDownloader(myResource);
            fileDownloader.extend(buttonToExtend);
        } catch (SQLException ex) {
            Logger.getLogger(Common.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public synchronized void prepareForPdfReport(String reportTemplate, String reportOutputFilename, Button buttonToExtend,
            String parameters) {
        Connection conn;
        try {
            conn = ConnectionHelper.getConnection();
            reportOutputFilename += ("_" + getDateAsString() + ".pdf");
            StreamResource myResource
                    = createPdfResource(conn,
                            reportTemplate, reportOutputFilename, parameters);
            FileDownloader fileDownloader = new FileDownloader(myResource);
            fileDownloader.extend(buttonToExtend);
        } catch (SQLException ex) {
            Logger.getLogger(Common.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Generate pdf report, and return it as a StreamResource
     *
     * @param conn Database connection
     * @param templatePath Report template path
     * @param reportFileName Pdf output file name
     * @return StreamResource with the generated pdf report
     */
    private StreamResource createPdfResource(final Connection conn, final String templatePath, String reportFileName) {
        return new StreamResource(() -> {
            ByteArrayOutputStream pdfBuffer = new ByteArrayOutputStream();
            ReportGenerator reportGenerator = new ReportGenerator();
            
            try {
                //Generate the report
//                    reportGenerator.designQuery(baseReportsPath + templatePath, conn, pdfBuffer);
                reportGenerator.executeReport(baseReportsPath + templatePath, conn, pdfBuffer);
                Log.info("1..baseReportPath::"+templatePath);
            } catch (JRException e) {
                e.printStackTrace();
                Log.error(">createPdfResource........", e);
                System.out.println(">createPdfResource........" + e);
            }
            // Return a stream from the buffer.
            return new ByteArrayInputStream(
                    pdfBuffer.toByteArray());
        }, reportFileName);
    }
    
    private StreamResource createPdfResource(final Connection conn, final String templatePath,
            String reportFileName, String sql) {
        return new StreamResource(() -> {
            ByteArrayOutputStream pdfBuffer = new ByteArrayOutputStream();
            ReportGenerator reportGenerator = new ReportGenerator();
            
            try {
                //Generate the report
                Log.info("templatePath::" + templatePath+" SQL::"+sql);
                reportGenerator.designSQLQuery(templatePath, conn, pdfBuffer, sql);
                Log.info("templatePath::" + templatePath);
            } catch (JRException e) {
                e.printStackTrace();
                Log.error(">createPdfResource........", e);
            }
            // Return a stream from the buffer.
            return new ByteArrayInputStream(
                    pdfBuffer.toByteArray());
        }, reportFileName);
    }

    /**
     * Convert a date to String
     *
     * @return String with date
     */
    private String getDateAsString() {
        return (String.valueOf(java.util.Calendar.getInstance().get(java.util.Calendar.YEAR))
                + String.valueOf(java.util.Calendar.getInstance().get(java.util.Calendar.MONTH) + 1)
                + String.valueOf(java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_MONTH))
                + String.valueOf(java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY))
                + String.valueOf(java.util.Calendar.getInstance().get(java.util.Calendar.MINUTE))
                + String.valueOf(java.util.Calendar.getInstance().get(java.util.Calendar.SECOND)));
    }
}
